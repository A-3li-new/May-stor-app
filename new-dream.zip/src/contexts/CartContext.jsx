
    import React, { createContext, useState, useContext, useEffect } from 'react';

    const CartContext = createContext();

    export const useCart = () => useContext(CartContext);

    export const CartProvider = ({ children }) => {
        const [cartItems, setCartItems] = useState(() => {
            try {
                const localData = localStorage.getItem('cartItems');
                return localData ? JSON.parse(localData) : [];
            } catch (error) {
                console.error("Could not parse cart items from localStorage", error);
                return [];
            }
        });

        useEffect(() => {
            localStorage.setItem('cartItems', JSON.stringify(cartItems));
        }, [cartItems]);

        const addToCart = (product, quantity = 1, size, color) => {
            setCartItems(prevItems => {
                const itemInCart = prevItems.find(item => item.id === product.id && item.size === size && item.color === color);
                if (itemInCart) {
                    return prevItems.map(item =>
                        item.id === product.id && item.size === size && item.color === color
                            ? { ...item, quantity: item.quantity + quantity }
                            : item
                    );
                } else {
                    return [...prevItems, { ...product, quantity, size, color }];
                }
            });
        };

        const removeFromCart = (productId, size, color) => {
            setCartItems(prevItems => prevItems.filter(item => !(item.id === productId && item.size === size && item.color === color)));
        };

        const updateQuantity = (productId, size, color, quantity) => {
            setCartItems(prevItems =>
                prevItems.map(item =>
                    item.id === productId && item.size === size && item.color === color
                        ? { ...item, quantity: quantity }
                        : item
                )
            );
        };

        const clearCart = () => {
            setCartItems([]);
        };

        const cartCount = cartItems.reduce((count, item) => count + item.quantity, 0);
        const cartTotal = cartItems.reduce((total, item) => total + item.price * item.quantity, 0);

        const value = {
            cartItems,
            addToCart,
            removeFromCart,
            updateQuantity,
            clearCart,
            cartCount,
            cartTotal
        };

        return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
    };
  
import React, { createContext, useState, useContext } from 'react';

    const NotificationContext = createContext();

    export const useNotifications = () => useContext(NotificationContext);

    export const NotificationsProvider = ({ children }) => {
        const [notifications, setNotifications] = useState([]);

        const addNotification = (message) => {
            const newNotification = {
                id: Date.now(),
                message,
                read: false,
                timestamp: new Date(),
            };
            setNotifications(prev => [newNotification, ...prev].slice(0, 10)); // Keep last 10
        };

        const markAsRead = (id) => {
            setNotifications(prev =>
                prev.map(n => (n.id === id ? { ...n, read: true } : n))
            );
        };

        const value = {
            notifications,
            addNotification,
            markAsRead,
        };

        return (
            <NotificationContext.Provider value={value}>
                {children}
            </NotificationContext.Provider>
        );
    };
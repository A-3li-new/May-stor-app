import React, { useState } from 'react';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
    import { useToast } from '@/components/ui/use-toast';
    import { motion } from 'framer-motion';

    const StaffProtection = ({ children }) => {
        const [isAuthenticated, setIsAuthenticated] = useState(!!sessionStorage.getItem('staff_auth'));
        const [password, setPassword] = useState('');
        const { toast } = useToast();

        const handleLogin = (e) => {
            e.preventDefault();
            // In a real app, this would be a more secure check
            if (password === 'superadmin2025') {
                sessionStorage.setItem('staff_auth', 'true');
                setIsAuthenticated(true);
                toast({
                    title: "تم التحقق بنجاح",
                });
            } else {
                toast({
                    variant: "destructive",
                    title: "كلمة مرور غير صحيحة",
                    description: "ليس لديك صلاحية الوصول لهذه الصفحة.",
                });
            }
        };

        if (isAuthenticated) {
            return children;
        }

        return (
            <div className="flex items-center justify-center h-full">
                <motion.div
                    initial={{ opacity: 0, y: -20 }}
                    animate={{ opacity: 1, y: 0 }}
                >
                    <Card className="w-full max-w-sm">
                        <CardHeader className="text-center">
                            <CardTitle className="text-2xl">مطلوب صلاحية وصول</CardTitle>
                            <CardDescription>هذه الصفحة محمية. يرجى إدخال كلمة المرور للمتابعة.</CardDescription>
                        </CardHeader>
                        <CardContent>
                            <form onSubmit={handleLogin} className="space-y-4">
                                <div className="space-y-2">
                                    <Label htmlFor="staff-password">كلمة مرور المدير</Label>
                                    <Input 
                                        id="staff-password" 
                                        type="password" 
                                        value={password}
                                        onChange={(e) => setPassword(e.target.value)}
                                    />
                                </div>
                                <Button type="submit" className="w-full">دخول</Button>
                            </form>
                        </CardContent>
                    </Card>
                </motion.div>
            </div>
        );
    };

    export default StaffProtection;
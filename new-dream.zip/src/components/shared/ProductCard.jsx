
    import React from 'react';
    import { Link } from 'react-router-dom';
    import { motion } from 'framer-motion';
    import { Button } from '@/components/ui/button';
    import { ShoppingCart } from 'lucide-react';
    import { useToast } from '@/components/ui/use-toast';

    const ProductCard = ({ product }) => {
        const { toast } = useToast();

        const handleAddToCart = () => {
            toast({
                title: "🚧 هذه الميزة غير مكتملة",
                description: "لإضافة المنتج للسلة، يرجى الذهاب لصفحة المنتج واختيار المقاس واللون.",
            });
        };

        return (
            <motion.div
                className="bg-white rounded-lg shadow-lg overflow-hidden group"
                whileHover={{ y: -5 }}
                transition={{ duration: 0.3 }}
            >
                <Link to={`/product/${product.id}`} className="block">
                    <div className="relative h-64">
                        <img 
                            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                            alt={product.name}
                         src="https://images.unsplash.com/photo-1671376354106-d8d21e55dddd" />
                        <div className="absolute top-2 left-2 bg-primary text-white text-xs font-bold px-2 py-1 rounded">
                            {product.brand}
                        </div>
                    </div>
                    <div className="p-4">
                        <h3 className="text-lg font-semibold text-gray-800 truncate">{product.name}</h3>
                        <p className="text-primary font-bold text-xl mt-2">{product.price} د.أ</p>
                    </div>
                </Link>
                <div className="p-4 pt-0">
                    <Button className="w-full" onClick={handleAddToCart}>
                        <ShoppingCart className="w-4 h-4 ml-2" />
                        أضف إلى السلة
                    </Button>
                </div>
            </motion.div>
        );
    };

    export default ProductCard;
  
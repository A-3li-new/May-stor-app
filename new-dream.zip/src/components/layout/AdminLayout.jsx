import React from 'react';
    import { NavLink, useNavigate, Link } from 'react-router-dom';
    import { LayoutDashboard, ShoppingBag, ClipboardList, Users, Ticket, LogOut, Settings, Home } from 'lucide-react';
    import { Button } from '@/components/ui/button';
    import { useToast } from '@/components/ui/use-toast';

    const AdminLayout = ({ children }) => {
        const navigate = useNavigate();
        const { toast } = useToast();

        const handleLogout = () => {
            localStorage.removeItem('admin_auth');
            localStorage.removeItem('staff_auth');
            toast({
                title: "تم تسجيل الخروج",
                description: "تم تسجيل خروجك بنجاح.",
            });
            navigate('/admin/login');
        };

        const navLinkClasses = ({ isActive }) =>
            `flex items-center px-4 py-2.5 text-sm font-medium rounded-lg transition-colors ${
                isActive ? 'bg-primary text-white' : 'text-gray-600 hover:bg-gray-100'
            }`;

        return (
            <div className="flex h-screen bg-gray-50">
                <aside className="w-64 bg-white border-l border-gray-200 flex flex-col">
                    <div className="flex items-center justify-center h-20 border-b">
                        <h1 className="text-2xl font-bold text-primary">لوحة التحكم</h1>
                    </div>
                    <nav className="flex-1 p-4 space-y-2">
                        <NavLink to="/admin" end className={navLinkClasses}>
                            <LayoutDashboard className="w-5 h-5 ml-3" />
                            نظرة عامة
                        </NavLink>
                        <NavLink to="/admin/products" className={navLinkClasses}>
                            <ShoppingBag className="w-5 h-5 ml-3" />
                            إدارة المنتجات
                        </NavLink>
                        <NavLink to="/admin/orders" className={navLinkClasses}>
                            <ClipboardList className="w-5 h-5 ml-3" />
                            إدارة الطلبات
                        </NavLink>
                        <NavLink to="/admin/staff" className={navLinkClasses}>
                            <Users className="w-5 h-5 ml-3" />
                            إدارة الموظفين
                        </NavLink>
                        <NavLink to="/admin/coupons" className={navLinkClasses}>
                            <Ticket className="w-5 h-5 ml-3" />
                            إدارة الكوبونات
                        </NavLink>
                        <NavLink to="/admin/settings" className={navLinkClasses}>
                            <Settings className="w-5 h-5 ml-3" />
                            الإعدادات
                        </NavLink>
                    </nav>
                    <div className="p-4 border-t space-y-2">
                        <Button variant="outline" className="w-full justify-start" asChild>
                            <Link to="/">
                                <Home className="w-5 h-5 ml-3" />
                                العودة للرئيسية
                            </Link>
                        </Button>
                        <Button variant="ghost" className="w-full justify-start" onClick={handleLogout}>
                            <LogOut className="w-5 h-5 ml-3" />
                            تسجيل الخروج
                        </Button>
                    </div>
                </aside>
                <main className="flex-1 overflow-y-auto p-8">
                    {children}
                </main>
            </div>
        );
    };

    export default AdminLayout;
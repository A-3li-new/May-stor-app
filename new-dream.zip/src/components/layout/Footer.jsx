import React from 'react';
    import { Link } from 'react-router-dom';
    import { Facebook, Instagram, Twitter } from 'lucide-react';

    const Footer = () => {
        const complaintNumber = '962779308837';

        return (
            <footer className="bg-secondary border-t">
                <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
                        <div>
                            <p className="font-bold text-lg text-foreground">Dream Collection</p>
                            <p className="mt-2 text-muted-foreground">
                                وجهتك الأولى لأرقى الأزياء النسائية.
                            </p>
                            <div className="flex space-x-4 rtl:space-x-reverse mt-4">
                                <a href="#" className="text-muted-foreground hover:text-primary"><Facebook /></a>
                                <a href="#" className="text-muted-foreground hover:text-primary"><Instagram /></a>
                                <a href="#" className="text-muted-foreground hover:text-primary"><Twitter /></a>
                            </div>
                        </div>
                        <div>
                            <p className="font-semibold text-foreground">روابط سريعة</p>
                            <ul className="mt-4 space-y-2">
                                <li><Link to="/about" className="text-muted-foreground hover:text-primary">من نحن</Link></li>
                                <li><Link to="/services" className="text-muted-foreground hover:text-primary">خدماتنا</Link></li>
                                <li><Link to="/track-order" className="text-muted-foreground hover:text-primary">تتبع طلبك</Link></li>
                                <li><Link to="/terms" className="text-muted-foreground hover:text-primary">الشروط والأحكام</Link></li>
                            </ul>
                        </div>
                        <div>
                            <p className="font-semibold text-foreground">خدمة العملاء</p>
                            <ul className="mt-4 space-y-2">
                                <li><p className="text-muted-foreground">البريد: dreamappstore6@gmail.com</p></li>
                                <li><a href={`https://wa.me/${complaintNumber}`} className="text-muted-foreground hover:text-primary">شكاوى واقتراحات</a></li>
                            </ul>
                        </div>
                        <div>
                            <p className="font-semibold text-foreground">اشترك في نشرتنا البريدية</p>
                            <p className="mt-2 text-muted-foreground">
                                كن أول من يعرف عن جديدنا وعروضنا.
                            </p>
                            <form className="mt-4 flex">
                                <input type="email" placeholder="بريدك الإلكتروني" className="w-full px-4 py-2 border border-input bg-background rounded-r-md focus:ring-primary focus:border-primary" />
                                <button type="submit" className="bg-primary text-primary-foreground px-4 py-2 rounded-l-md hover:bg-primary/90">اشتراك</button>
                            </form>
                        </div>
                    </div>
                    <div className="mt-12 border-t pt-8 text-center text-muted-foreground">
                        <p>&copy; {new Date().getFullYear()} Dream Collection. جميع الحقوق محفوظة.</p>
                    </div>
                </div>
            </footer>
        );
    };

    export default Footer;
import React from 'react';
    import { Link, NavLink } from 'react-router-dom';
    import { ShoppingBag, User, Bell, Truck } from 'lucide-react';
    import { useCart } from '@/contexts/CartContext';
    import { Button } from '@/components/ui/button';
    import { motion } from 'framer-motion';
    import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
    import { useNotifications } from '@/contexts/NotificationContext';

    const Header = () => {
        const { cartCount } = useCart();
        const { notifications, markAsRead } = useNotifications();
        const unreadCount = notifications.filter(n => !n.read).length;

        const navLinkClasses = ({ isActive }) =>
            `text-foreground/80 hover:text-primary transition-colors duration-300 ${isActive ? 'text-primary font-semibold' : ''}`;

        return (
            <header className="bg-background/80 backdrop-blur-sm shadow-sm sticky top-0 z-50 border-b">
                <div className="container mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="flex items-center justify-between h-20">
                        <div className="flex items-center space-x-2 rtl:space-x-reverse">
                            <Link to="/track-order">
                                <Button variant="ghost" size="icon">
                                    <Truck className="h-6 w-6 text-foreground/80" />
                                </Button>
                            </Link>
                            <Link to="/cart" className="relative">
                                <Button variant="ghost" size="icon">
                                    <ShoppingBag className="h-6 w-6 text-foreground/80" />
                                    {cartCount > 0 && (
                                        <motion.span
                                            initial={{ scale: 0 }}
                                            animate={{ scale: 1 }}
                                            className="absolute -top-1 -right-1 bg-primary text-primary-foreground text-xs rounded-full h-5 w-5 flex items-center justify-center">
                                            {cartCount}
                                        </motion.span>
                                    )}
                                </Button>
                            </Link>
                             <Popover>
                                <PopoverTrigger asChild>
                                    <Button variant="ghost" size="icon" className="relative">
                                        <Bell className="h-6 w-6 text-foreground/80" />
                                        {unreadCount > 0 && (
                                            <motion.span
                                                initial={{ scale: 0 }}
                                                animate={{ scale: 1 }}
                                                className="absolute -top-1 -right-1 bg-destructive text-destructive-foreground text-xs rounded-full h-5 w-5 flex items-center justify-center">
                                                {unreadCount}
                                            </motion.span>
                                        )}
                                    </Button>
                                </PopoverTrigger>
                                <PopoverContent className="w-80">
                                    <div className="grid gap-4">
                                        <div className="space-y-2">
                                            <h4 className="font-medium leading-none">الإشعارات</h4>
                                            <p className="text-sm text-muted-foreground">
                                                آخر تحديثات طلباتك.
                                            </p>
                                        </div>
                                        <div className="grid gap-2">
                                            {notifications.length > 0 ? notifications.map(n => (
                                                <div key={n.id} onClick={() => markAsRead(n.id)} className={`text-sm p-2 rounded-md cursor-pointer ${n.read ? 'text-muted-foreground' : 'font-semibold bg-accent'}`}>
                                                    <p>{n.message}</p>
                                                    <p className="text-xs text-muted-foreground mt-1">{new Date(n.timestamp).toLocaleString()}</p>
                                                </div>
                                            )) : <p className="text-sm text-muted-foreground">لا توجد إشعارات جديدة.</p>}
                                        </div>
                                    </div>
                                </PopoverContent>
                            </Popover>
                            <Link to="/admin/login">
                                <Button variant="ghost" size="icon">
                                    <User className="h-6 w-6 text-foreground/80" />
                                </Button>
                            </Link>
                        </div>

                        <nav className="hidden md:flex md:space-x-8 md:rtl:space-x-reverse">
                            <NavLink to="/" className={navLinkClasses}>الرئيسية</NavLink>
                            <NavLink to="/brand/Classic" className={navLinkClasses}>Classic</NavLink>
                            <NavLink to="/brand/Ghyma" className={navLinkClasses}>Ghyma</NavLink>
                            <NavLink to="/brand/Designerr. Mix" className={navLinkClasses}>Designerr. Mix</NavLink>
                            <NavLink to="/about" className={navLinkClasses}>من نحن</NavLink>
                            <NavLink to="/services" className={navLinkClasses}>خدماتنا</NavLink>
                        </nav>

                        <div className="flex-shrink-0">
                            <Link to="/">
                                <img src="https://storage.googleapis.com/hostinger-horizons-assets-prod/684258db-ab55-4704-81bc-5f92298cb9db/c53898a1e1c01eb9dfea761143f13c27.jpg" alt="Dream Collection Logo" className="h-12" />
                            </Link>
                        </div>
                    </div>
                </div>
            </header>
        );
    };

    export default Header;
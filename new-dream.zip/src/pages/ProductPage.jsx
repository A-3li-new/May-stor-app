
    import React, { useState } from 'react';
    import { Helmet } from 'react-helmet';
    import { useParams } from 'react-router-dom';
    import { mockProducts } from '@/lib/mockData';
    import { Button } from '@/components/ui/button';
    import { useCart } from '@/contexts/CartContext';
    import { useToast } from '@/components/ui/use-toast';
    import { Star, Minus, Plus, ShoppingCart } from 'lucide-react';
    import { motion } from 'framer-motion';

    const ProductPage = () => {
        const { productId } = useParams();
        const product = mockProducts.find(p => p.id === productId);
        const { addToCart } = useCart();
        const { toast } = useToast();

        const [quantity, setQuantity] = useState(1);
        const [selectedSize, setSelectedSize] = useState(product?.sizes[0]);
        const [selectedColor, setSelectedColor] = useState(product?.colors[0]);

        if (!product) {
            return <div className="text-center py-20">المنتج غير موجود.</div>;
        }

        const handleAddToCart = () => {
            addToCart(product, quantity, selectedSize, selectedColor);
            toast({
                title: "تمت الإضافة إلى السلة",
                description: `${product.name} أضيف إلى سلة التسوق بنجاح.`,
            });
        };

        const renderStars = (rating) => {
            const stars = [];
            for (let i = 1; i <= 5; i++) {
                stars.push(
                    <Star key={i} className={`w-5 h-5 ${i <= rating ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}`} />
                );
            }
            return stars;
        };

        return (
            <>
                <Helmet>
                    <title>{product.name} - Dream Boutique</title>
                    <meta name="description" content={product.description} />
                </Helmet>
                <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
                    <div className="grid md:grid-cols-2 gap-12">
                        <motion.div initial={{ opacity: 0, x: -50 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.5 }}>
                            <img 
                                className="w-full h-auto rounded-lg shadow-lg object-cover"
                                alt={product.name}
                             src="https://images.unsplash.com/photo-1671376354106-d8d21e55dddd" />
                        </motion.div>
                        <motion.div initial={{ opacity: 0, x: 50 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.5, delay: 0.2 }}>
                            <p className="text-sm text-primary font-semibold">{product.brand}</p>
                            <h1 className="text-4xl font-bold text-gray-800 mt-2">{product.name}</h1>
                            <div className="flex items-center mt-4">
                                <div className="flex items-center">{renderStars(product.rating)}</div>
                                <span className="text-gray-500 mr-2">({product.reviews.length} مراجعات)</span>
                            </div>
                            <p className="text-gray-600 mt-4 text-lg">{product.description}</p>
                            <p className="text-primary font-bold text-3xl mt-6">{product.price} د.أ</p>

                            <div className="mt-8">
                                <div className="mb-6">
                                    <h3 className="text-sm font-bold text-gray-700 tracking-wide mb-2">اللون</h3>
                                    <div className="flex gap-2">
                                        {product.colors.map(color => (
                                            <button key={color} onClick={() => setSelectedColor(color)} className={`px-4 py-2 border rounded-md text-sm ${selectedColor === color ? 'bg-primary text-white border-primary' : 'bg-white'}`}>
                                                {color}
                                            </button>
                                        ))}
                                    </div>
                                </div>
                                <div className="mb-6">
                                    <h3 className="text-sm font-bold text-gray-700 tracking-wide mb-2">المقاس</h3>
                                    <div className="flex gap-2">
                                        {product.sizes.map(size => (
                                            <button key={size} onClick={() => setSelectedSize(size)} className={`px-4 py-2 border rounded-md text-sm ${selectedSize === size ? 'bg-primary text-white border-primary' : 'bg-white'}`}>
                                                {size}
                                            </button>
                                        ))}
                                    </div>
                                </div>
                            </div>

                            <div className="flex items-center gap-4 mt-8">
                                <div className="flex items-center border rounded-md">
                                    <Button variant="ghost" size="icon" onClick={() => setQuantity(q => Math.max(1, q - 1))}><Minus className="w-4 h-4" /></Button>
                                    <span className="w-12 text-center">{quantity}</span>
                                    <Button variant="ghost" size="icon" onClick={() => setQuantity(q => q + 1)}><Plus className="w-4 h-4" /></Button>
                                </div>
                                <Button size="lg" className="flex-1" onClick={handleAddToCart}>
                                    <ShoppingCart className="w-5 h-5 ml-2" />
                                    أضف إلى السلة
                                </Button>
                            </div>
                        </motion.div>
                    </div>

                    <div className="mt-16">
                        <h2 className="text-2xl font-bold text-gray-800 mb-4">مراجعات المنتج</h2>
                        {product.reviews.length > 0 ? (
                            <div className="space-y-6">
                                {product.reviews.map(review => (
                                    <div key={review.id} className="bg-white p-6 rounded-lg border">
                                        <div className="flex items-center mb-2">
                                            <p className="font-semibold">{review.user}</p>
                                            <div className="flex items-center mr-4">{renderStars(review.rating)}</div>
                                        </div>
                                        <p className="text-gray-600">{review.comment}</p>
                                    </div>
                                ))}
                            </div>
                        ) : (
                            <p className="text-gray-500">لا توجد مراجعات لهذا المنتج حتى الآن.</p>
                        )}
                    </div>
                </div>
            </>
        );
    };

    export default ProductPage;
  
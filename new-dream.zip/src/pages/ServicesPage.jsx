
    import React from 'react';
    import { Helmet } from 'react-helmet';
    import { motion } from 'framer-motion';
    import { PinOff as SewingPin, Truck, Gift } from 'lucide-react';

    const services = [
        {
            icon: <SewingPin className="w-12 h-12 text-primary" />,
            title: "تفصيل حسب الطلب",
            description: "نقدم خدمة التفصيل حسب الطلب لتناسب مقاسك وذوقك الخاص. فريق من الخياطين المهرة جاهزون لتحقيق رؤيتك."
        },
        {
            icon: <Truck className="w-12 h-12 text-primary" />,
            title: "شحن سريع وآمن",
            description: "نوفر خدمة شحن سريعة وموثوقة لجميع مناطق المملكة. طلبك سيصلك بأمان وفي أسرع وقت ممكن."
        },
        {
            icon: <Gift className="w-12 h-12 text-primary" />,
            title: "تغليف هدايا",
            description: "هل ترغبين في إرسال هدية؟ يمكننا تغليف طلبك بشكل أنيق وإضافة بطاقة إهداء حسب طلبك."
        }
    ];

    const ServicesPage = () => {
        return (
            <>
                <Helmet>
                    <title>خدماتنا - Dream Boutique</title>
                    <meta name="description" content="تعرفي على الخدمات المميزة التي نقدمها في Dream Boutique، من التفصيل حسب الطلب إلى الشحن السريع." />
                </Helmet>
                <div className="bg-gray-50">
                    <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-16">
                        <motion.div
                            initial={{ opacity: 0, y: -20 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ duration: 0.5 }}
                            className="text-center mb-12"
                        >
                            <h1 className="text-4xl font-bold text-gray-800">خدماتنا</h1>
                            <p className="mt-2 text-lg text-gray-500">نحن هنا لنجعل تجربتك استثنائية</p>
                        </motion.div>

                        <div className="grid md:grid-cols-3 gap-8">
                            {services.map((service, index) => (
                                <motion.div
                                    key={index}
                                    className="bg-white p-8 rounded-lg shadow-md text-center"
                                    initial={{ opacity: 0, y: 20 }}
                                    whileInView={{ opacity: 1, y: 0 }}
                                    viewport={{ once: true }}
                                    transition={{ duration: 0.5, delay: index * 0.2 }}
                                >
                                    <div className="flex justify-center mb-4">
                                        {service.icon}
                                    </div>
                                    <h2 className="text-2xl font-semibold text-gray-800 mb-2">{service.title}</h2>
                                    <p className="text-gray-600">{service.description}</p>
                                </motion.div>
                            ))}
                        </div>
                    </div>
                </div>
            </>
        );
    };

    export default ServicesPage;
  
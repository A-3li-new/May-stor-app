import React from 'react';
    import { Helmet } from 'react-helmet';
    import { motion } from 'framer-motion';
    import { Link } from 'react-router-dom';
    import { Button } from '@/components/ui/button';
    import ProductCard from '@/components/shared/ProductCard';
    import { mockProducts, brands } from '@/lib/mockData';
    import { Instagram } from 'lucide-react';

    const HomePage = () => {
        const featuredProducts = mockProducts.slice(0, 4);
        const watermarkUrl = 'https://storage.googleapis.com/hostinger-horizons-assets-prod/684258db-ab55-4704-81bc-5f92298cb9db/926a400ffd3a26a09fb1d32201be28bb.jpg';

        const cardVariants = {
            offscreen: {
                y: 50,
                opacity: 0
            },
            onscreen: {
                y: 0,
                opacity: 1,
                transition: {
                    type: "spring",
                    bounce: 0.4,
                    duration: 0.8
                }
            }
        };

        return (
            <>
                <Helmet>
                    <title>الرئيسية - Dream Collection</title>
                    <meta name="description" content="اكتشفي أرقى الأزياء النسائية في Dream Collection. تشكيلات حصرية من براندات Classic, Ghyma, و Designerr. Mix." />
                </Helmet>
                <div className="space-y-20 pb-20">
                    <section className={`relative h-[70vh] bg-beige-100 flex items-center justify-center text-center text-black overflow-hidden bg-no-repeat bg-cover bg-center`} style={{ backgroundImage: `url(${watermarkUrl})`, backgroundSize: 'contain', backgroundRepeat: 'repeat' }}>
                        <div className="absolute inset-0 bg-background/60 backdrop-blur-sm"></div>
                        <motion.div
                            className="relative z-10 p-8"
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ duration: 0.8, ease: [0.25, 1, 0.5, 1] }}
                        >
                            <h1 className="text-4xl md:text-6xl font-bold tracking-tight text-foreground">Dream Collection</h1>
                            <p className="mt-4 max-w-2xl mx-auto text-lg md:text-xl text-muted-foreground">
                                اكتشفي مجموعة حصرية من الملابس العصرية والأنيقة من أفضل البراندات
                            </p>
                            <Button asChild size="lg" className="mt-8 bg-foreground text-background hover:bg-foreground/90 rounded-full px-10 py-6 text-base">
                                <Link to="/brand/Classic">
                                    تسوقي الآن
                                </Link>
                            </Button>
                        </motion.div>
                    </section>

                    <section className="container mx-auto px-4 sm:px-6 lg:px-8">
                        <motion.div
                            initial="offscreen"
                            whileInView="onscreen"
                            viewport={{ once: true, amount: 0.5 }}
                            transition={{ staggerChildren: 0.2 }}
                            className="mt-10 grid md:grid-cols-3 gap-8"
                        >
                            {brands.map((brand) => (
                                <motion.div 
                                    key={brand.id} 
                                    className="bg-card rounded-lg shadow-lg overflow-hidden text-center flex flex-col group"
                                    variants={cardVariants}
                                >
                                    <div className="relative p-6 flex-grow flex flex-col items-center justify-center bg-secondary overflow-hidden h-80">
                                        <img src={brand.logo} alt={`${brand.name} Logo`} className="h-full w-full object-contain transition-transform duration-500 ease-in-out group-hover:scale-110" />
                                    </div>
                                    <div className="p-6 flex flex-col items-center space-y-3">
                                        <Button asChild className="w-full bg-foreground text-background hover:bg-foreground/90 rounded-full py-5">
                                            <Link to={`/brand/${brand.id}`}>اكتشف المزيد</Link>
                                        </Button>
                                        <Button asChild variant="outline" className="w-full border-primary text-primary hover:bg-primary hover:text-primary-foreground rounded-full py-5">
                                            <a href={brand.instagram} target="_blank" rel="noopener noreferrer">
                                                <Instagram className="ml-2 h-4 w-4" />
                                                انستجرام
                                            </a>
                                        </Button>
                                    </div>
                                </motion.div>
                            ))}
                        </motion.div>
                    </section>

                    <section className="container mx-auto px-4 sm:px-6 lg:px-8">
                        <motion.div
                            initial={{ opacity: 0, y: 20 }}
                            whileInView={{ opacity: 1, y: 0 }}
                            viewport={{ once: true, amount: 0.3 }}
                            transition={{ duration: 0.5 }}
                        >
                            <h2 className="text-3xl font-bold text-center text-foreground">المنتجات المميزة</h2>
                            <p className="mt-2 text-center text-muted-foreground">نخبة من أفضل تصاميمنا المختارة لكِ</p>
                        </motion.div>
                        <div className="mt-10 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
                            {featuredProducts.map((product, index) => (
                                <motion.div
                                    key={product.id}
                                    initial="offscreen"
                                    whileInView="onscreen"
                                    viewport={{ once: true, amount: 0.3 }}
                                    transition={{ delay: index * 0.1 }}
                                    variants={cardVariants}
                                >
                                    <ProductCard product={product} />
                                </motion.div>
                            ))}
                        </div>
                    </section>
                </div>
            </>
        );
    };

    export default HomePage;
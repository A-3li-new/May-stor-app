
    import React from 'react';
    import { Helmet } from 'react-helmet';
    import { useCart } from '@/contexts/CartContext';
    import { Button } from '@/components/ui/button';
    import { Link } from 'react-router-dom';
    import { Minus, Plus, Trash2, ArrowLeft } from 'lucide-react';
    import { motion, AnimatePresence } from 'framer-motion';

    const CartPage = () => {
        const { cartItems, cartTotal, updateQuantity, removeFromCart, clearCart } = useCart();

        return (
            <>
                <Helmet>
                    <title>سلة التسوق - Dream Boutique</title>
                    <meta name="description" content="مراجعة المنتجات في سلة التسوق الخاصة بك والمتابعة للدفع." />
                </Helmet>
                <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
                    <h1 className="text-3xl font-bold text-center mb-8">سلة التسوق</h1>
                    {cartItems.length === 0 ? (
                        <div className="text-center py-16">
                            <p className="text-xl text-gray-500 mb-4">سلة التسوق فارغة.</p>
                            <Button asChild>
                                <Link to="/">
                                    <ArrowLeft className="mr-2 h-4 w-4" />
                                    العودة للتسوق
                                </Link>
                            </Button>
                        </div>
                    ) : (
                        <div className="grid lg:grid-cols-3 gap-8">
                            <div className="lg:col-span-2 space-y-4">
                                <AnimatePresence>
                                    {cartItems.map(item => (
                                        <motion.div
                                            key={`${item.id}-${item.size}-${item.color}`}
                                            layout
                                            initial={{ opacity: 0, y: 20 }}
                                            animate={{ opacity: 1, y: 0 }}
                                            exit={{ opacity: 0, x: -50, transition: { duration: 0.3 } }}
                                            className="flex items-center bg-white p-4 rounded-lg shadow-sm"
                                        >
                                            <img  className="w-24 h-24 object-cover rounded-md mr-4" alt={item.name} src="https://images.unsplash.com/photo-1662542987920-4d37a1a755de" />
                                            <div className="flex-grow">
                                                <p className="font-semibold">{item.name}</p>
                                                <p className="text-sm text-gray-500">المقاس: {item.size}, اللون: {item.color}</p>
                                                <p className="text-primary font-bold mt-1">{item.price} د.أ</p>
                                            </div>
                                            <div className="flex items-center border rounded-md mx-4">
                                                <Button variant="ghost" size="icon" onClick={() => updateQuantity(item.id, item.size, item.color, Math.max(1, item.quantity - 1))}><Minus className="w-4 h-4" /></Button>
                                                <span className="w-10 text-center">{item.quantity}</span>
                                                <Button variant="ghost" size="icon" onClick={() => updateQuantity(item.id, item.size, item.color, item.quantity + 1)}><Plus className="w-4 h-4" /></Button>
                                            </div>
                                            <p className="font-semibold w-24 text-center">{(item.price * item.quantity).toFixed(2)} د.أ</p>
                                            <Button variant="ghost" size="icon" onClick={() => removeFromCart(item.id, item.size, item.color)}>
                                                <Trash2 className="w-5 h-5 text-red-500" />
                                            </Button>
                                        </motion.div>
                                    ))}
                                </AnimatePresence>
                                <Button variant="outline" onClick={clearCart}>إفراغ السلة</Button>
                            </div>
                            <div className="lg:col-span-1">
                                <div className="bg-white p-6 rounded-lg shadow-sm sticky top-24">
                                    <h2 className="text-xl font-bold mb-4">ملخص الطلب</h2>
                                    <div className="flex justify-between mb-2">
                                        <p>المجموع الفرعي</p>
                                        <p>{cartTotal.toFixed(2)} د.أ</p>
                                    </div>
                                    <div className="flex justify-between mb-4">
                                        <p>الشحن</p>
                                        <p>5.00 د.أ</p>
                                    </div>
                                    <div className="border-t pt-4 flex justify-between font-bold text-lg">
                                        <p>المجموع الكلي</p>
                                        <p>{(cartTotal + 5).toFixed(2)} د.أ</p>
                                    </div>
                                    <Button asChild size="lg" className="w-full mt-6">
                                        <Link to="/checkout">المتابعة للدفع</Link>
                                    </Button>
                                </div>
                            </div>
                        </div>
                    )}
                </div>
            </>
        );
    };

    export default CartPage;
  
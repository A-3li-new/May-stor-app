
    import React from 'react';
    import { Helmet } from 'react-helmet';
    import { motion } from 'framer-motion';

    const AboutPage = () => {
        return (
            <>
                <Helmet>
                    <title>من نحن - Dream Boutique</title>
                    <meta name="description" content="تعرفي على قصة Dream Boutique، رؤيتنا، ورسالتنا في عالم الأزياء النسائية." />
                </Helmet>
                <div className="bg-white">
                    <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-16">
                        <div className="grid lg:grid-cols-2 gap-16 items-center">
                            <motion.div
                                initial={{ opacity: 0, x: -50 }}
                                whileInView={{ opacity: 1, x: 0 }}
                                viewport={{ once: true }}
                                transition={{ duration: 0.7 }}
                            >
                                <h1 className="text-4xl font-bold text-gray-800">قصتنا</h1>
                                <p className="mt-4 text-lg text-gray-600">
                                    وُلد Dream Boutique من شغف بالأناقة والجمال. بدأنا كحلم صغير لجمع أرقى التصاميم من ماركات محلية مبدعة تحت سقف واحد، لنقدم للمرأة العصرية خيارات تعبر عن شخصيتها الفريدة.
                                </p>
                                <p className="mt-4 text-lg text-gray-600">
                                    نحن نؤمن بأن الموضة هي أكثر من مجرد ملابس؛ إنها فن، وثقة، وقصة ترويها كل امرأة.
                                </p>
                            </motion.div>
                            <motion.div
                                initial={{ opacity: 0, scale: 0.9 }}
                                whileInView={{ opacity: 1, scale: 1 }}
                                viewport={{ once: true }}
                                transition={{ duration: 0.7 }}
                            >
                                <img 
                                    className="rounded-lg shadow-xl w-full h-auto"
                                    alt="مجموعة من الأقمشة والأدوات المستخدمة في تصميم الأزياء"
                                 src="https://images.unsplash.com/photo-1626541219447-9e00f8707d14" />
                            </motion.div>
                        </div>

                        <div className="mt-24 text-center">
                            <h2 className="text-3xl font-bold text-gray-800">رؤيتنا ورسالتنا</h2>
                            <div className="mt-8 grid md:grid-cols-2 gap-8">
                                <motion.div
                                    className="bg-gray-50 p-8 rounded-lg"
                                    initial={{ opacity: 0, y: 20 }}
                                    whileInView={{ opacity: 1, y: 0 }}
                                    viewport={{ once: true }}
                                    transition={{ duration: 0.5, delay: 0.2 }}
                                >
                                    <h3 className="text-2xl font-semibold text-primary">رؤيتنا</h3>
                                    <p className="mt-2 text-gray-600">أن نكون الوجهة الأولى والموثوقة للمرأة الباحثة عن التميز والأناقة في عالم الموضة، من خلال تقديم تشكيلات حصرية وتجربة تسوق لا مثيل لها.</p>
                                </motion.div>
                                <motion.div
                                    className="bg-gray-50 p-8 rounded-lg"
                                    initial={{ opacity: 0, y: 20 }}
                                    whileInView={{ opacity: 1, y: 0 }}
                                    viewport={{ once: true }}
                                    transition={{ duration: 0.5, delay: 0.4 }}
                                >
                                    <h3 className="text-2xl font-semibold text-primary">رسالتنا</h3>
                                    <p className="mt-2 text-gray-600">تمكين المرأة من خلال الأزياء التي تعزز ثقتها بنفسها وتعكس جمالها الداخلي والخارجي، مع الالتزام بأعلى معايير الجودة والابتكار في كل قطعة نقدمها.</p>
                                </motion.div>
                            </div>
                        </div>
                    </div>
                </div>
            </>
        );
    };

    export default AboutPage;
  

    import React, { useState } from 'react';
    import { Helmet } from 'react-helmet';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { mockOrders } from '@/lib/mockData';
    import { motion } from 'framer-motion';

    const TrackOrderPage = () => {
        const [orderId, setOrderId] = useState('');
        const [order, setOrder] = useState(null);
        const [error, setError] = useState('');

        const handleTrackOrder = (e) => {
            e.preventDefault();
            const foundOrder = mockOrders.find(o => o.id.toLowerCase() === orderId.toLowerCase());
            if (foundOrder) {
                setOrder(foundOrder);
                setError('');
            } else {
                setOrder(null);
                setError('لم يتم العثور على طلب بهذا الرقم. يرجى التحقق مرة أخرى.');
            }
        };

        const getStatusStep = (status) => {
            const statuses = ['جاري التنفيذ', 'جاهز للشحن', 'بالطريق إليك', 'تم التسليم'];
            const index = statuses.indexOf(status);
            if (status.startsWith('ملغي') || status.startsWith('مرتجع')) return -1;
            return index;
        };

        const currentStep = order ? getStatusStep(order.status) : -1;
        const timelineStatuses = ['جاري التنفيذ', 'جاهز للشحن', 'بالطريق إليك', 'تم التسليم'];

        return (
            <>
                <Helmet>
                    <title>تتبع الطلب - Dream Boutique</title>
                    <meta name="description" content="تتبع حالة طلبك في Dream Boutique." />
                </Helmet>
                <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
                    <div className="max-w-2xl mx-auto">
                        <h1 className="text-3xl font-bold text-center mb-8">تتبع طلبك</h1>
                        <form onSubmit={handleTrackOrder} className="flex items-end gap-4 mb-12">
                            <div className="flex-grow">
                                <Label htmlFor="orderId">رقم الطلب</Label>
                                <Input
                                    id="orderId"
                                    value={orderId}
                                    onChange={(e) => setOrderId(e.target.value)}
                                    placeholder="مثال: DB001"
                                />
                            </div>
                            <Button type="submit">تتبع</Button>
                        </form>

                        {error && <p className="text-red-500 text-center">{error}</p>}

                        {order && (
                            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="bg-white p-8 rounded-lg shadow-md">
                                <h2 className="text-2xl font-semibold mb-2">تفاصيل الطلب #{order.id}</h2>
                                <p className="text-lg font-bold text-primary mb-6">الحالة الحالية: {order.status}</p>

                                {currentStep > -1 && (
                                    <div className="relative my-8">
                                        <div className="absolute left-1/2 transform -translate-x-1/2 w-0.5 h-full bg-gray-200"></div>
                                        <div className="absolute left-1/2 transform -translate-x-1/2 w-0.5 h-full bg-primary transition-all duration-500" style={{ height: `${(currentStep / (timelineStatuses.length - 1)) * 100}%` }}></div>
                                        {timelineStatuses.map((status, index) => (
                                            <div key={status} className="flex items-center justify-center mb-8 last:mb-0">
                                                <div className={`w-6 h-6 rounded-full flex items-center justify-center z-10 ${index <= currentStep ? 'bg-primary' : 'bg-gray-300'}`}>
                                                    {index <= currentStep && <div className="w-3 h-3 bg-white rounded-full"></div>}
                                                </div>
                                                <p className={`mr-4 font-semibold ${index <= currentStep ? 'text-primary' : 'text-gray-500'}`}>{status}</p>
                                            </div>
                                        ))}
                                    </div>
                                )}

                                {(order.status.startsWith('ملغي') || order.status.startsWith('مرتجع')) && (
                                    <div className="text-center p-4 bg-red-50 border border-red-200 rounded-md">
                                        <p className="font-semibold text-red-700">{order.status}</p>
                                    </div>
                                )}
                            </motion.div>
                        )}
                    </div>
                </div>
            </>
        );
    };

    export default TrackOrderPage;
  
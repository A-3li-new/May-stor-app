import React, { useState } from 'react';
    import { Helmet } from 'react-helmet';
    import { useForm } from 'react-hook-form';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { useCart } from '@/contexts/CartContext';
    import { useNavigate } from 'react-router-dom';
    import { useToast } from '@/components/ui/use-toast';
    import { mockCoupons } from '@/lib/mockData';

    const CheckoutPage = () => {
        const { register, handleSubmit, formState: { errors } } = useForm();
        const { cartItems, cartTotal, clearCart } = useCart();
        const navigate = useNavigate();
        const { toast } = useToast();
        const [couponCode, setCouponCode] = useState('');
        const [discount, setDiscount] = useState(0);

        const handleApplyCoupon = () => {
            const coupon = mockCoupons.find(c => c.code.toLowerCase() === couponCode.toLowerCase() && c.status === 'نشط');
            if (coupon) {
                let discountValue = 0;
                if (coupon.discountType === 'percentage') {
                    discountValue = cartTotal * (coupon.value / 100);
                } else {
                    discountValue = coupon.value;
                }
                setDiscount(discountValue);
                toast({
                    title: "تم تطبيق الكوبون!",
                    description: `لقد حصلت على خصم بقيمة ${discountValue.toFixed(2)} د.أ`,
                });
            } else {
                setDiscount(0);
                toast({
                    variant: "destructive",
                    title: "كوبون غير صالح",
                    description: "كود الخصم الذي أدخلته غير صحيح أو منتهي الصلاحية.",
                });
            }
        };

        const finalTotal = cartTotal + 5 - discount;

        const onSubmit = (data) => {
            const orderId = `DB${Date.now()}`;
            console.log("Order Submitted:", { orderId, ...data, items: cartItems, total: finalTotal });
            
            toast({
                title: "تم استلام طلبك بنجاح!",
                description: `شكراً لك. رقم طلبك هو ${orderId}`,
            });

            clearCart();
            navigate(`/order-success/${orderId}`);
        };

        if (cartItems.length === 0) {
            navigate('/cart');
            return null;
        }

        return (
            <>
                <Helmet>
                    <title>الدفع - Dream Collection</title>
                    <meta name="description" content="أكمل عملية الشراء في Dream Collection." />
                </Helmet>
                <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
                    <h1 className="text-3xl font-bold text-center mb-8">إتمام الطلب</h1>
                    <div className="grid lg:grid-cols-2 gap-12">
                        <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
                            <div>
                                <h2 className="text-xl font-semibold mb-4">معلومات الشحن</h2>
                                <div className="space-y-4">
                                    <div>
                                        <Label htmlFor="name">الاسم الكامل</Label>
                                        <Input id="name" {...register("name", { required: "الاسم مطلوب" })} />
                                        {errors.name && <p className="text-red-500 text-sm mt-1">{errors.name.message}</p>}
                                    </div>
                                    <div>
                                        <Label htmlFor="phone">رقم الهاتف</Label>
                                        <Input id="phone" type="tel" {...register("phone", { required: "رقم الهاتف مطلوب" })} />
                                        {errors.phone && <p className="text-red-500 text-sm mt-1">{errors.phone.message}</p>}
                                    </div>
                                    <div>
                                        <Label htmlFor="address">العنوان بالتفصيل</Label>
                                        <Input id="address" {...register("address", { required: "العنوان مطلوب" })} />
                                        {errors.address && <p className="text-red-500 text-sm mt-1">{errors.address.message}</p>}
                                    </div>
                                </div>
                            </div>
                            <div>
                                <h2 className="text-xl font-semibold mb-4">طريقة الدفع</h2>
                                <div className="space-y-2">
                                    <div className="flex items-center p-4 border rounded-md">
                                        <input type="radio" id="cod" value="cod" {...register("paymentMethod", { required: true })} className="ml-2" defaultChecked />
                                        <Label htmlFor="cod">الدفع عند الاستلام</Label>
                                    </div>
                                    <div className="flex items-center p-4 border rounded-md bg-gray-100 text-gray-400">
                                        <input type="radio" id="card" value="card" {...register("paymentMethod")} className="ml-2" disabled />
                                        <Label htmlFor="card">بطاقة الائتمان (قريباً)</Label>
                                    </div>
                                </div>
                            </div>
                            <Button type="submit" size="lg" className="w-full">تأكيد الطلب</Button>
                        </form>
                        <div className="bg-secondary p-8 rounded-lg">
                            <h2 className="text-xl font-semibold mb-4">طلبك</h2>
                            <div className="space-y-4 max-h-60 overflow-y-auto pr-2">
                                {cartItems.map(item => (
                                    <div key={`${item.id}-${item.size}-${item.color}`} className="flex justify-between items-start">
                                        <div>
                                            <p className="font-semibold">{item.name} <span className="text-sm font-normal">x {item.quantity}</span></p>
                                            <p className="text-sm text-muted-foreground">المقاس: {item.size}, اللون: {item.color}</p>
                                        </div>
                                        <p>{(item.price * item.quantity).toFixed(2)} د.أ</p>
                                    </div>
                                ))}
                            </div>
                            <div className="border-t my-4"></div>
                             <div className="flex gap-2 mb-4">
                                <Input placeholder="كود الخصم" value={couponCode} onChange={(e) => setCouponCode(e.target.value)} />
                                <Button type="button" variant="outline" onClick={handleApplyCoupon}>تطبيق</Button>
                            </div>
                            <div className="space-y-2">
                                <div className="flex justify-between">
                                    <p>المجموع الفرعي</p>
                                    <p>{cartTotal.toFixed(2)} د.أ</p>
                                </div>
                                <div className="flex justify-between">
                                    <p>الشحن</p>
                                    <p>5.00 د.أ</p>
                                </div>
                                {discount > 0 && (
                                    <div className="flex justify-between text-green-600">
                                        <p>الخصم</p>
                                        <p>-{discount.toFixed(2)} د.أ</p>
                                    </div>
                                )}
                                <div className="border-t my-2"></div>
                                <div className="flex justify-between font-bold text-lg">
                                    <p>المجموع الكلي</p>
                                    <p>{finalTotal.toFixed(2)} د.أ</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </>
        );
    };

    export default CheckoutPage;
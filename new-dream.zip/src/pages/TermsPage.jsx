import React from 'react';
    import { Helmet } from 'react-helmet';
    import { motion } from 'framer-motion';

    const TermsPage = () => {
        return (
            <>
                <Helmet>
                    <title>الشروط والأحكام - Dream Collection</title>
                    <meta name="description" content="اطلع على الشروط والأحكام الخاصة بمتجر Dream Collection." />
                </Helmet>
                <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-16">
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.5 }}
                        className="max-w-4xl mx-auto"
                    >
                        <h1 className="text-4xl font-bold text-center mb-8">الشروط والأحكام</h1>
                        <div className="bg-card p-8 rounded-lg shadow-md space-y-6 text-lg leading-relaxed">
                            <h2 className="text-2xl font-semibold text-primary">1. مقدمة</h2>
                            <p>
                                أهلاً بك في Dream Collection. باستخدامك لموقعنا، فإنك توافق على الالتزام بهذه الشروط والأحكام. يرجى قراءتها بعناية.
                            </p>

                            <h2 className="text-2xl font-semibold text-primary">2. سياسة المعاينة والاسترجاع</h2>
                            <p className="font-bold">
                                المعاينة مسموحة فقط في وجود المندوب. بمجرد مغادرة المندوب، لا تُقبل أي مطالبات أو مرتجعات.
                            </p>
                            <p>
                                نرجو من عملائنا الكرام التأكد جيدًا من الطلب (المقاس، اللون، الجودة) أثناء عملية التسليم وقبل دفع المبلغ. توقيعك على إيصال الاستلام أو دفع المبلغ للمندوب يعتبر موافقة نهائية على سلامة المنتج ومطابقته لطلبك.
                            </p>

                            <h2 className="text-2xl font-semibold text-primary">3. الطلبات والدفع</h2>
                            <p>
                                جميع الأسعار المعروضة بالدينار الأردني. نحتفظ بالحق في تغيير الأسعار في أي وقت دون إشعار مسبق. طريقة الدفع المتاحة حاليًا هي الدفع عند الاستلام.
                            </p>

                            <h2 className="text-2xl font-semibold text-primary">4. الشحن والتوصيل</h2>
                            <p>
                                نسعى لتوصيل الطلبات في أسرع وقت ممكن. قد تختلف مدة التوصيل حسب المنطقة. سيتم إبلاغك بالموعد المتوقع للتسليم.
                            </p>

                            <h2 className="text-2xl font-semibold text-primary">5. الملكية الفكرية</h2>
                            <p>
                                جميع المحتويات الموجودة على هذا الموقع، بما في ذلك النصوص والصور والشعارات، هي ملك لـ Dream Collection ومحمية بموجب قوانين حقوق النشر.
                            </p>

                            <h2 className="text-2xl font-semibold text-primary">6. تعديل الشروط</h2>
                            <p>
                                نحتفظ بالحق في تعديل هذه الشروط والأحكام في أي وقت. ستكون النسخة المحدثة سارية المفعول فور نشرها على الموقع.
                            </p>
                        </div>
                    </motion.div>
                </div>
            </>
        );
    };

    export default TermsPage;

    import React from 'react';
    import { Helmet } from 'react-helmet';
    import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
    import { DollarSign, ShoppingBag, Users, ClipboardList } from 'lucide-react';
    import { mockOrders, mockProducts, mockStaff } from '@/lib/mockData';

    const AdminDashboardPage = () => {
        const totalRevenue = mockOrders.filter(o => o.status === 'تم التسليم').reduce((sum, order) => sum + order.total, 0);
        const totalOrders = mockOrders.length;
        const totalProducts = mockProducts.length;
        const totalStaff = mockStaff.length;

        const recentOrders = mockOrders.slice(0, 5);

        return (
            <>
                <Helmet>
                    <title>لوحة التحكم - Dream Boutique</title>
                </Helmet>
                <div className="space-y-8">
                    <h1 className="text-3xl font-bold">نظرة عامة</h1>
                    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
                        <Card>
                            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                                <CardTitle className="text-sm font-medium">إجمالي الإيرادات</CardTitle>
                                <DollarSign className="h-4 w-4 text-muted-foreground" />
                            </CardHeader>
                            <CardContent>
                                <div className="text-2xl font-bold">{totalRevenue.toFixed(2)} د.أ</div>
                                <p className="text-xs text-muted-foreground">فقط من الطلبات المكتملة</p>
                            </CardContent>
                        </Card>
                        <Card>
                            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                                <CardTitle className="text-sm font-medium">إجمالي الطلبات</CardTitle>
                                <ClipboardList className="h-4 w-4 text-muted-foreground" />
                            </CardHeader>
                            <CardContent>
                                <div className="text-2xl font-bold">+{totalOrders}</div>
                                <p className="text-xs text-muted-foreground">منذ بداية العمل</p>
                            </CardContent>
                        </Card>
                        <Card>
                            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                                <CardTitle className="text-sm font-medium">عدد المنتجات</CardTitle>
                                <ShoppingBag className="h-4 w-4 text-muted-foreground" />
                            </CardHeader>
                            <CardContent>
                                <div className="text-2xl font-bold">{totalProducts}</div>
                                <p className="text-xs text-muted-foreground">منتج متوفر حالياً</p>
                            </CardContent>
                        </Card>
                        <Card>
                            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                                <CardTitle className="text-sm font-medium">عدد الموظفين</CardTitle>
                                <Users className="h-4 w-4 text-muted-foreground" />
                            </CardHeader>
                            <CardContent>
                                <div className="text-2xl font-bold">{totalStaff}</div>
                                <p className="text-xs text-muted-foreground">موظف مسجل في النظام</p>
                            </CardContent>
                        </Card>
                    </div>
                    <div>
                        <h2 className="text-2xl font-bold mb-4">أحدث الطلبات</h2>
                        <Card>
                            <CardContent className="p-0">
                                <div className="overflow-x-auto">
                                    <table className="w-full text-sm text-right">
                                        <thead className="text-xs text-gray-700 uppercase bg-gray-50">
                                            <tr>
                                                <th scope="col" className="px-6 py-3">رقم الطلب</th>
                                                <th scope="col" className="px-6 py-3">العميل</th>
                                                <th scope="col" className="px-6 py-3">الحالة</th>
                                                <th scope="col" className="px-6 py-3">المجموع</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {recentOrders.map(order => (
                                                <tr key={order.id} className="bg-white border-b">
                                                    <td className="px-6 py-4 font-medium text-gray-900">{order.id}</td>
                                                    <td className="px-6 py-4">{order.customerName}</td>
                                                    <td className="px-6 py-4">
                                                        <span className="px-2 py-1 text-xs font-medium text-green-800 bg-green-100 rounded-full">{order.status}</span>
                                                    </td>
                                                    <td className="px-6 py-4">{order.total.toFixed(2)} د.أ</td>
                                                </tr>
                                            ))}
                                        </tbody>
                                    </table>
                                </div>
                            </CardContent>
                        </Card>
                    </div>
                </div>
            </>
        );
    };

    export default AdminDashboardPage;
  
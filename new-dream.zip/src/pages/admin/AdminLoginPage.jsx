
    import React from 'react';
    import { Helmet } from 'react-helmet';
    import { useForm } from 'react-hook-form';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
    import { useNavigate } from 'react-router-dom';
    import { useToast } from '@/components/ui/use-toast';
    import { motion } from 'framer-motion';

    const AdminLoginPage = () => {
        const { register, handleSubmit, formState: { errors } } = useForm();
        const navigate = useNavigate();
        const { toast } = useToast();

        const onSubmit = (data) => {
            if (data.username === 'admin' && data.password === 'admin123') {
                localStorage.setItem('admin_auth', 'true');
                toast({
                    title: "أهلاً بك!",
                    description: "تم تسجيل الدخول بنجاح.",
                });
                navigate('/admin');
            } else {
                toast({
                    variant: "destructive",
                    title: "خطأ في تسجيل الدخول",
                    description: "اسم المستخدم أو كلمة المرور غير صحيحة.",
                });
            }
        };

        return (
            <>
                <Helmet>
                    <title>تسجيل دخول الإدارة - Dream Boutique</title>
                </Helmet>
                <div className="flex items-center justify-center min-h-screen bg-gray-100">
                    <motion.div
                        initial={{ opacity: 0, y: -50 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.5 }}
                    >
                        <Card className="w-full max-w-sm">
                            <CardHeader className="text-center">
                                <CardTitle className="text-2xl">تسجيل دخول الإدارة</CardTitle>
                                <CardDescription>أدخل بياناتك للوصول إلى لوحة التحكم</CardDescription>
                            </CardHeader>
                            <CardContent>
                                <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
                                    <div className="space-y-2">
                                        <Label htmlFor="username">اسم المستخدم</Label>
                                        <Input id="username" defaultValue="admin" {...register("username", { required: "اسم المستخدم مطلوب" })} />
                                        {errors.username && <p className="text-red-500 text-sm">{errors.username.message}</p>}
                                    </div>
                                    <div className="space-y-2">
                                        <Label htmlFor="password">كلمة المرور</Label>
                                        <Input id="password" type="password" defaultValue="admin123" {...register("password", { required: "كلمة المرور مطلوبة" })} />
                                        {errors.password && <p className="text-red-500 text-sm">{errors.password.message}</p>}
                                    </div>
                                    <Button type="submit" className="w-full">تسجيل الدخول</Button>
                                </form>
                            </CardContent>
                        </Card>
                    </motion.div>
                </div>
            </>
        );
    };

    export default AdminLoginPage;
  
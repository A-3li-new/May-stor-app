import React, { useState } from 'react';
    import { Helmet } from 'react-helmet';
    import { Button } from '@/components/ui/button';
    import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
    import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
    import { mockStaff } from '@/lib/mockData';
    import { PlusCircle, Edit, Trash2 } from 'lucide-react';
    import { useToast } from '@/components/ui/use-toast';
    import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
    import { Input } from "@/components/ui/input";

    const AdminStaffPage = () => {
        const { toast } = useToast();
        const [staff, setStaff] = useState(mockStaff);
        const [isModalOpen, setModalOpen] = useState(false);

        const handleAddStaff = (event) => {
            event.preventDefault();
            const formData = new FormData(event.target);
            const newStaff = {
                id: `S${Date.now()}`,
                name: formData.get('name'),
                role: formData.get('role'),
                salary: parseFloat(formData.get('salary')),
                status: 'نشط',
                joinDate: new Date().toISOString().split('T')[0],
            };
            setStaff(prev => [newStaff, ...prev]);
            setModalOpen(false);
            toast({ title: "تمت إضافة الموظف بنجاح!" });
        };

        const handleDelete = (staffId) => {
            setStaff(prev => prev.filter(s => s.id !== staffId));
            toast({ variant: "destructive", title: "تم حذف الموظف." });
        };

        return (
            <>
                <Helmet>
                    <title>إدارة الموظفين - Dream Collection</title>
                </Helmet>
                <div className="space-y-8">
                    <div className="flex items-center justify-between">
                        <h1 className="text-3xl font-bold">إدارة الموظفين</h1>
                        <Dialog open={isModalOpen} onOpenChange={setModalOpen}>
                            <DialogTrigger asChild>
                                <Button>
                                    <PlusCircle className="mr-2 h-4 w-4" /> إضافة موظف جديد
                                </Button>
                            </DialogTrigger>
                            <DialogContent>
                                <DialogHeader>
                                    <DialogTitle>إضافة موظف جديد</DialogTitle>
                                </DialogHeader>
                                <form onSubmit={handleAddStaff} className="space-y-4 py-4">
                                    <Input name="name" placeholder="اسم الموظف" required />
                                    <Input name="role" placeholder="الدور الوظيفي" required />
                                    <Input name="salary" type="number" placeholder="الراتب" required />
                                    <DialogFooter>
                                        <Button type="submit">إضافة</Button>
                                    </DialogFooter>
                                </form>
                            </DialogContent>
                        </Dialog>
                    </div>
                    <Card>
                        <CardHeader>
                            <CardTitle>قائمة الموظفين</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <Table>
                                <TableHeader>
                                    <TableRow>
                                        <TableHead>الاسم</TableHead>
                                        <TableHead>الدور الوظيفي</TableHead>
                                        <TableHead>الحالة</TableHead>
                                        <TableHead>الراتب</TableHead>
                                        <TableHead>إجراءات</TableHead>
                                    </TableRow>
                                </TableHeader>
                                <TableBody>
                                    {staff.map((s) => (
                                        <TableRow key={s.id}>
                                            <TableCell className="font-medium">{s.name}</TableCell>
                                            <TableCell>{s.role}</TableCell>
                                            <TableCell>
                                                <span className={`px-2 py-1 text-xs font-medium rounded-full ${s.status === 'نشط' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                                                    {s.status}
                                                </span>
                                            </TableCell>
                                            <TableCell>{s.salary.toFixed(2)} د.أ</TableCell>
                                            <TableCell className="flex gap-2">
                                                <Button variant="ghost" size="icon" onClick={() => toast({ title: "ميزة قيد التطوير" })}>
                                                    <Edit className="h-4 w-4" />
                                                </Button>
                                                <Button variant="ghost" size="icon" onClick={() => handleDelete(s.id)}>
                                                    <Trash2 className="h-4 w-4 text-destructive" />
                                                </Button>
                                            </TableCell>
                                        </TableRow>
                                    ))}
                                </TableBody>
                            </Table>
                        </CardContent>
                    </Card>
                </div>
            </>
        );
    };

    export default AdminStaffPage;
import React, { useState, useMemo } from 'react';
    import { Helmet } from 'react-helmet';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { Card, CardContent, CardFooter, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
    import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
    import { mockOrders, mockProducts } from '@/lib/mockData';
    import { PlusCircle, Share2, Edit, Trash2 } from 'lucide-react';
    import { useToast } from '@/components/ui/use-toast';
    import { useNotifications } from '@/contexts/NotificationContext';

    const AdminOrdersPage = () => {
        const { toast } = useToast();
        const { addNotification } = useNotifications();
        const [orders, setOrders] = useState(mockOrders);
        const [searchTerm, setSearchTerm] = useState('');
        const [isAddModalOpen, setAddModalOpen] = useState(false);

        const handleAddOrder = (event) => {
            event.preventDefault();
            const formData = new FormData(event.target);
            const newOrder = {
                id: `DB${Date.now()}`,
                customerName: formData.get('customerName'),
                phone: formData.get('phone'),
                address: formData.get('address'),
                trackingNumber: formData.get('trackingNumber'),
                source: formData.get('source'),
                status: 'جاري التنفيذ',
                notes: formData.get('notes'),
                total: 0, // Should be calculated based on products
                products: [],
            };
            setOrders(prev => [newOrder, ...prev]);
            setAddModalOpen(false);
            toast({
                title: "تمت إضافة الطلب بنجاح!",
            });
        };

        const handleShare = (order) => {
            const orderDetails = `
    طلب جديد من Dream Collection
    -----------------------------
    اسم العميل: ${order.customerName}
    رقم الهاتف: ${order.phone}
    العنوان: ${order.address}
    رقم التتبع: ${order.trackingNumber}
    الملاحظات: ${order.notes || 'لا يوجد'}
    المصدر: ${order.source}
    الحالة: ${order.status}
    `;
            navigator.clipboard.writeText(orderDetails.trim());
            toast({
                title: "تم نسخ تفاصيل الطلب!",
                description: "يمكنك الآن لصقها وإرسالها.",
            });
        };

        const handleStatusChange = (orderId, newStatus) => {
            setOrders(prevOrders =>
                prevOrders.map(order =>
                    order.id === orderId ? { ...order, status: newStatus } : order
                )
            );
            toast({
                title: "تم تحديث الحالة",
                description: `تم تغيير حالة الطلب #${orderId} إلى ${newStatus}.`,
            });
            addNotification(`تحديث الطلب #${orderId}: الحالة الآن هي "${newStatus}".`);
        };

        const handleDelete = (orderId) => {
            setOrders(prev => prev.filter(o => o.id !== orderId));
            toast({
                variant: "destructive",
                title: "تم حذف الطلب",
                description: `تم حذف الطلب رقم #${orderId} بنجاح.`,
            });
        };

        const filteredOrders = useMemo(() => {
            return orders.filter(order =>
                order.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                order.trackingNumber.toLowerCase().includes(searchTerm.toLowerCase())
            );
        }, [orders, searchTerm]);

        const statusOptions = ['جاري التنفيذ', 'جاهز للشحن', 'بالطريق إليك', 'تم التسليم', 'مرتجع', 'ملغي من العميل'];

        return (
            <>
                <Helmet>
                    <title>إدارة الطلبات - Dream Collection</title>
                </Helmet>
                <div className="space-y-8">
                    <div className="flex items-center justify-between gap-4">
                        <h1 className="text-3xl font-bold">إدارة الطلبات</h1>
                        <div className="flex-grow max-w-md">
                            <Input 
                                placeholder="ابحث برقم التتبع أو اسم العميل..."
                                value={searchTerm}
                                onChange={(e) => setSearchTerm(e.target.value)}
                            />
                        </div>
                        <Dialog open={isAddModalOpen} onOpenChange={setAddModalOpen}>
                            <DialogTrigger asChild>
                                <Button>
                                    <PlusCircle className="mr-2 h-4 w-4" /> إضافة طلب يدوي
                                </Button>
                            </DialogTrigger>
                            <DialogContent>
                                <DialogHeader>
                                    <DialogTitle>إضافة طلب يدوي</DialogTitle>
                                    <DialogDescription>أدخل تفاصيل الطلب الجديد هنا.</DialogDescription>
                                </DialogHeader>
                                <form onSubmit={handleAddOrder} className="space-y-4">
                                    <Input name="customerName" placeholder="اسم العميل" required />
                                    <Input name="phone" placeholder="رقم الهاتف" required />
                                    <Input name="address" placeholder="العنوان" required />
                                    <Input name="trackingNumber" placeholder="رقم التتبع" />
                                    <Input name="source" placeholder="المصدر (انستجرام، فيسبوك...)" required />
                                    <Input name="notes" placeholder="ملاحظات إضافية" />
                                    <DialogFooter>
                                        <Button type="submit">إضافة الطلب</Button>
                                    </DialogFooter>
                                </form>
                            </DialogContent>
                        </Dialog>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        {filteredOrders.map((order) => (
                            <Card key={order.id} className="flex flex-col">
                                <CardHeader>
                                    <div className="flex justify-between items-start">
                                        <div>
                                            <CardTitle>العميل: {order.customerName}</CardTitle>
                                            <CardDescription>#{order.id}</CardDescription>
                                        </div>
                                        <Button variant="ghost" size="icon" onClick={() => handleShare(order)}>
                                            <Share2 className="h-5 w-5" />
                                        </Button>
                                    </div>
                                </CardHeader>
                                <CardContent className="space-y-3 flex-grow">
                                    <p><strong>الهاتف:</strong> {order.phone}</p>
                                    <p><strong>العنوان:</strong> {order.address}</p>
                                    <p><strong>رقم التتبع:</strong> {order.trackingNumber}</p>
                                    <p><strong>المصدر:</strong> {order.source}</p>
                                    {order.notes && <p><strong>ملاحظات:</strong> {order.notes}</p>}
                                    <div>
                                        <strong>الحالة:</strong>
                                        <select
                                            value={order.status}
                                            onChange={(e) => handleStatusChange(order.id, e.target.value)}
                                            className="p-1 border rounded-md bg-transparent mr-2"
                                        >
                                            {statusOptions.map(status => (
                                                <option key={status} value={status}>{status}</option>
                                            ))}
                                        </select>
                                    </div>
                                </CardContent>
                                <CardFooter className="border-t pt-4 flex justify-end gap-2">
                                    <Button variant="outline" size="sm" onClick={() => toast({ title: "ميزة قيد التطوير" })}>
                                        <Edit className="ml-1 h-4 w-4" /> تعديل
                                    </Button>
                                    <Button variant="destructive" size="sm" onClick={() => handleDelete(order.id)}>
                                        <Trash2 className="ml-1 h-4 w-4" /> حذف
                                    </Button>
                                </CardFooter>
                            </Card>
                        ))}
                    </div>
                    {filteredOrders.length === 0 && (
                        <div className="text-center py-10">
                            <p className="text-gray-500">لا توجد طلبات تطابق بحثك.</p>
                        </div>
                    )}
                </div>
            </>
        );
    };

    export default AdminOrdersPage;
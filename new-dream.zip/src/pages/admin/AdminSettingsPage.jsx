import React from 'react';
    import { Helmet } from 'react-helmet';
    import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { useToast } from '@/components/ui/use-toast';
    import { Textarea } from '@/components/ui/textarea';

    const AdminSettingsPage = () => {
        const { toast } = useToast();

        const handleSaveChanges = (e) => {
            e.preventDefault();
            toast({
                title: "تم حفظ التغييرات!",
                description: "تم تحديث إعداداتك بنجاح.",
            });
        };

        return (
            <>
                <Helmet>
                    <title>الإعدادات - Dream Collection</title>
                </Helmet>
                <div className="space-y-8 max-w-4xl mx-auto">
                    <h1 className="text-3xl font-bold">الإعدادات</h1>
                    
                    <Card>
                        <CardHeader>
                            <CardTitle>معلومات المتجر</CardTitle>
                            <CardDescription>تحديث المعلومات الأساسية لمتجرك.</CardDescription>
                        </CardHeader>
                        <CardContent>
                            <form onSubmit={handleSaveChanges} className="space-y-4">
                                <div className="space-y-2">
                                    <Label htmlFor="store-name">اسم المتجر</Label>
                                    <Input id="store-name" defaultValue="Dream Collection" />
                                </div>
                                <div className="space-y-2">
                                    <Label htmlFor="store-address">عنوان المتجر</Label>
                                    <Input id="store-address" defaultValue="عمان, الأردن" />
                                </div>
                                <div className="space-y-2">
                                    <Label htmlFor="store-phone">رقم الهاتف الرسمي</Label>
                                    <Input id="store-phone" type="tel" defaultValue="962779308837" />
                                </div>
                                <div className="space-y-2">
                                    <Label htmlFor="store-whatsapp">رابط واتساب</Label>
                                    <Input id="store-whatsapp" type="url" defaultValue="https://wa.me/962779308837" />
                                </div>
                                <Button type="submit">حفظ التغييرات</Button>
                            </form>
                        </CardContent>
                    </Card>

                    <Card>
                        <CardHeader>
                            <CardTitle>رسائل الإشعارات</CardTitle>
                            <CardDescription>تخصيص الرسائل التلقائية التي تصل للعملاء.</CardDescription>
                        </CardHeader>
                        <CardContent>
                            <form onSubmit={handleSaveChanges} className="space-y-4">
                                <div className="space-y-2">
                                    <Label htmlFor="msg-processing">رسالة "جاري التنفيذ"</Label>
                                    <Textarea id="msg-processing" defaultValue="طلبك #{orderId} قيد التنفيذ وسيتم تجهيزه قريباً." />
                                </div>
                                <div className="space-y-2">
                                    <Label htmlFor="msg-shipped">رسالة "تم الشحن"</Label>
                                    <Textarea id="msg-shipped" defaultValue="تم شحن طلبك #{orderId}! نتوقع وصوله خلال 2-3 أيام عمل." />
                                </div>
                                <div className="space-y-2">
                                    <Label htmlFor="msg-delivered">رسالة "تم التسليم"</Label>
                                    <Textarea id="msg-delivered" defaultValue="تم تسليم طلبك #{orderId}. شكراً لتسوقك معنا!" />
                                </div>
                                <Button type="submit">حفظ الرسائل</Button>
                            </form>
                        </CardContent>
                    </Card>
                </div>
            </>
        );
    };

    export default AdminSettingsPage;
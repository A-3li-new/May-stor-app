import React, { useState } from 'react';
    import { Helmet } from 'react-helmet';
    import { Button } from '@/components/ui/button';
    import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
    import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
    import { mockProducts } from '@/lib/mockData';
    import { PlusCircle, MoreHorizontal } from 'lucide-react';
    import { useToast } from '@/components/ui/use-toast';
    import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
    import { Input } from "@/components/ui/input";
    import { Label } from "@/components/ui/label";

    const AdminProductsPage = () => {
        const { toast } = useToast();
        const [products, setProducts] = useState(mockProducts);
        const [open, setOpen] = useState(false);

        const handleAddProduct = (event) => {
            event.preventDefault();
            const formData = new FormData(event.target);
            const newProduct = {
                id: `p${Date.now()}`,
                name: formData.get('name'),
                brand: formData.get('brand'),
                price: parseFloat(formData.get('price')),
                stock: parseInt(formData.get('stock')),
                description: formData.get('description'),
                image: URL.createObjectURL(formData.get('image')),
                sizes: formData.get('sizes').split(','),
                colors: formData.get('colors').split(','),
                rating: 0,
                reviews: []
            };
            setProducts(prev => [newProduct, ...prev]);
            setOpen(false);
            toast({
                title: "تمت إضافة المنتج بنجاح!",
                description: `تمت إضافة ${newProduct.name} إلى قائمة المنتجات.`,
            });
        };

        const handleAction = () => {
            toast({
                title: "🚧 هذه الميزة غير متوفرة بعد",
                description: "يمكنك طلبها في رسالتك القادمة! 🚀",
            });
        };

        return (
            <>
                <Helmet>
                    <title>إدارة المنتجات - Dream Boutique</title>
                </Helmet>
                <div className="space-y-8">
                    <div className="flex items-center justify-between">
                        <h1 className="text-3xl font-bold">إدارة المنتجات</h1>
                        <Dialog open={open} onOpenChange={setOpen}>
                            <DialogTrigger asChild>
                                <Button>
                                    <PlusCircle className="mr-2 h-4 w-4" /> إضافة منتج جديد
                                </Button>
                            </DialogTrigger>
                            <DialogContent className="sm:max-w-[425px]">
                                <DialogHeader>
                                    <DialogTitle>إضافة منتج جديد</DialogTitle>
                                    <DialogDescription>
                                        أدخل تفاصيل المنتج الجديد هنا.
                                    </DialogDescription>
                                </DialogHeader>
                                <form onSubmit={handleAddProduct} className="grid gap-4 py-4">
                                    <div className="grid grid-cols-4 items-center gap-4">
                                        <Label htmlFor="name" className="text-right">الاسم</Label>
                                        <Input id="name" name="name" className="col-span-3" required />
                                    </div>
                                    <div className="grid grid-cols-4 items-center gap-4">
                                        <Label htmlFor="brand" className="text-right">البراند</Label>
                                        <Input id="brand" name="brand" className="col-span-3" required />
                                    </div>
                                    <div className="grid grid-cols-4 items-center gap-4">
                                        <Label htmlFor="price" className="text-right">السعر</Label>
                                        <Input id="price" name="price" type="number" className="col-span-3" required />
                                    </div>
                                    <div className="grid grid-cols-4 items-center gap-4">
                                        <Label htmlFor="stock" className="text-right">المخزون</Label>
                                        <Input id="stock" name="stock" type="number" className="col-span-3" required />
                                    </div>
                                    <div className="grid grid-cols-4 items-center gap-4">
                                        <Label htmlFor="sizes" className="text-right">المقاسات</Label>
                                        <Input id="sizes" name="sizes" placeholder="S,M,L" className="col-span-3" required />
                                    </div>
                                    <div className="grid grid-cols-4 items-center gap-4">
                                        <Label htmlFor="colors" className="text-right">الألوان</Label>
                                        <Input id="colors" name="colors" placeholder="أسود,أبيض" className="col-span-3" required />
                                    </div>
                                    <div className="grid grid-cols-4 items-center gap-4">
                                        <Label htmlFor="description" className="text-right">الوصف</Label>
                                        <Input id="description" name="description" className="col-span-3" required />
                                    </div>
                                    <div className="grid grid-cols-4 items-center gap-4">
                                        <Label htmlFor="image" className="text-right">الصورة</Label>
                                        <Input id="image" name="image" type="file" className="col-span-3" required />
                                    </div>
                                    <DialogFooter>
                                        <Button type="submit">إضافة المنتج</Button>
                                    </DialogFooter>
                                </form>
                            </DialogContent>
                        </Dialog>
                    </div>
                    <Card>
                        <CardHeader>
                            <CardTitle>قائمة المنتجات</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <Table>
                                <TableHeader>
                                    <TableRow>
                                        <TableHead>المنتج</TableHead>
                                        <TableHead>البراند</TableHead>
                                        <TableHead>السعر</TableHead>
                                        <TableHead>المخزون</TableHead>
                                        <TableHead>إجراءات</TableHead>
                                    </TableRow>
                                </TableHeader>
                                <TableBody>
                                    {products.map((product) => (
                                        <TableRow key={product.id}>
                                            <TableCell className="font-medium">{product.name}</TableCell>
                                            <TableCell>{product.brand}</TableCell>
                                            <TableCell>{product.price.toFixed(2)} د.أ</TableCell>
                                            <TableCell>{product.stock}</TableCell>
                                            <TableCell>
                                                <Button variant="ghost" size="icon" onClick={handleAction}>
                                                    <MoreHorizontal className="h-4 w-4" />
                                                </Button>
                                            </TableCell>
                                        </TableRow>
                                    ))}
                                </TableBody>
                            </Table>
                        </CardContent>
                    </Card>
                </div>
            </>
        );
    };

    export default AdminProductsPage;
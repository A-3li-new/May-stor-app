import React, { useState } from 'react';
    import { Helmet } from 'react-helmet';
    import { Button } from '@/components/ui/button';
    import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
    import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
    import { mockCoupons } from '@/lib/mockData';
    import { PlusCircle, Edit, Trash2 } from 'lucide-react';
    import { useToast } from '@/components/ui/use-toast';
    import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
    import { Input } from "@/components/ui/input";
    import { Label } from "@/components/ui/label";
    import { Switch } from "@/components/ui/switch";

    const AdminCouponsPage = () => {
        const { toast } = useToast();
        const [coupons, setCoupons] = useState(mockCoupons);
        const [isModalOpen, setModalOpen] = useState(false);

        const handleAddCoupon = (event) => {
            event.preventDefault();
            const formData = new FormData(event.target);
            const newCoupon = {
                id: `C${Date.now()}`,
                code: formData.get('code'),
                discountType: formData.get('discountType'),
                value: parseFloat(formData.get('value')),
                status: 'نشط',
                expiryDate: formData.get('expiryDate'),
            };
            setCoupons(prev => [newCoupon, ...prev]);
            setModalOpen(false);
            toast({
                title: "تمت إضافة الكوبون بنجاح!",
            });
        };

        const toggleStatus = (couponId) => {
            setCoupons(prev => prev.map(c => c.id === couponId ? { ...c, status: c.status === 'نشط' ? 'غير نشط' : 'نشط' } : c));
            toast({ title: "تم تغيير حالة الكوبون." });
        };

        const handleDelete = (couponId) => {
            setCoupons(prev => prev.filter(c => c.id !== couponId));
            toast({ variant: "destructive", title: "تم حذف الكوبون." });
        };

        return (
            <>
                <Helmet>
                    <title>إدارة الكوبونات - Dream Collection</title>
                </Helmet>
                <div className="space-y-8">
                    <div className="flex items-center justify-between">
                        <h1 className="text-3xl font-bold">إدارة أكواد الخصم</h1>
                        <Dialog open={isModalOpen} onOpenChange={setModalOpen}>
                            <DialogTrigger asChild>
                                <Button>
                                    <PlusCircle className="mr-2 h-4 w-4" /> إضافة كوبون جديد
                                </Button>
                            </DialogTrigger>
                            <DialogContent>
                                <DialogHeader>
                                    <DialogTitle>إضافة كوبون جديد</DialogTitle>
                                </DialogHeader>
                                <form onSubmit={handleAddCoupon} className="space-y-4 py-4">
                                    <Input name="code" placeholder="كود الخصم" required />
                                    <select name="discountType" className="w-full p-2 border rounded-md bg-card" required>
                                        <option value="percentage">نسبة مئوية</option>
                                        <option value="fixed">مبلغ ثابت</option>
                                    </select>
                                    <Input name="value" type="number" placeholder="قيمة الخصم" required />
                                    <Input name="expiryDate" type="date" required />
                                    <DialogFooter>
                                        <Button type="submit">إضافة</Button>
                                    </DialogFooter>
                                </form>
                            </DialogContent>
                        </Dialog>
                    </div>
                    <Card>
                        <CardHeader>
                            <CardTitle>قائمة الكوبونات</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <Table>
                                <TableHeader>
                                    <TableRow>
                                        <TableHead>الكود</TableHead>
                                        <TableHead>النوع</TableHead>
                                        <TableHead>القيمة</TableHead>
                                        <TableHead>تاريخ الانتهاء</TableHead>
                                        <TableHead>الحالة</TableHead>
                                        <TableHead>إجراءات</TableHead>
                                    </TableRow>
                                </TableHeader>
                                <TableBody>
                                    {coupons.map((coupon) => (
                                        <TableRow key={coupon.id}>
                                            <TableCell className="font-medium">{coupon.code}</TableCell>
                                            <TableCell>{coupon.discountType === 'percentage' ? 'نسبة' : 'ثابت'}</TableCell>
                                            <TableCell>{coupon.discountType === 'percentage' ? `${coupon.value}%` : `${coupon.value.toFixed(2)} د.أ`}</TableCell>
                                            <TableCell>{coupon.expiryDate}</TableCell>
                                            <TableCell>
                                                <Switch
                                                    checked={coupon.status === 'نشط'}
                                                    onCheckedChange={() => toggleStatus(coupon.id)}
                                                />
                                            </TableCell>
                                            <TableCell className="flex gap-2">
                                                <Button variant="ghost" size="icon" onClick={() => toast({ title: "ميزة قيد التطوير" })}>
                                                    <Edit className="h-4 w-4" />
                                                </Button>
                                                <Button variant="ghost" size="icon" onClick={() => handleDelete(coupon.id)}>
                                                    <Trash2 className="h-4 w-4 text-destructive" />
                                                </Button>
                                            </TableCell>
                                        </TableRow>
                                    ))}
                                </TableBody>
                            </Table>
                        </CardContent>
                    </Card>
                </div>
            </>
        );
    };

    export default AdminCouponsPage;

    import React from 'react';
    import { Helmet } from 'react-helmet';
    import { useParams, Link } from 'react-router-dom';
    import { Button } from '@/components/ui/button';
    import { CheckCircle, ArrowLeft } from 'lucide-react';
    import { motion } from 'framer-motion';

    const OrderSuccessPage = () => {
        const { orderId } = useParams();

        return (
            <>
                <Helmet>
                    <title>تم استلام الطلب - Dream Boutique</title>
                    <meta name="description" content="صفحة تأكيد نجاح الطلب." />
                </Helmet>
                <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-20">
                    <motion.div
                        initial={{ opacity: 0, scale: 0.8 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ duration: 0.5, type: 'spring' }}
                        className="max-w-md mx-auto text-center bg-white p-10 rounded-lg shadow-lg"
                    >
                        <CheckCircle className="w-20 h-20 text-green-500 mx-auto mb-6" />
                        <h1 className="text-3xl font-bold text-gray-800">شكراً لك!</h1>
                        <p className="text-lg text-gray-600 mt-2">تم استلام طلبك بنجاح.</p>
                        <p className="mt-4 text-gray-500">
                            رقم طلبك هو: <span className="font-bold text-primary">{orderId}</span>
                        </p>
                        <p className="mt-2 text-gray-500">
                            سيتم التواصل معك قريباً لتأكيد تفاصيل الشحن.
                        </p>
                        <div className="mt-8 flex flex-col sm:flex-row justify-center gap-4">
                            <Button asChild>
                                <Link to="/">
                                    <ArrowLeft className="mr-2 h-4 w-4" />
                                    العودة للرئيسية
                                </Link>
                            </Button>
                            <Button asChild variant="outline">
                                <Link to="/track-order">
                                    تتبع طلبك
                                </Link>
                            </Button>
                        </div>
                    </motion.div>
                </div>
            </>
        );
    };

    export default OrderSuccessPage;
  
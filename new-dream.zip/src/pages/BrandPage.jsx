import React, { useState, useMemo } from 'react';
    import { Helmet } from 'react-helmet';
    import { useParams, Link } from 'react-router-dom';
    import { mockProducts, brands } from '@/lib/mockData';
    import ProductCard from '@/components/shared/ProductCard';
    import { motion } from 'framer-motion';
    import { Slider } from '@/components/ui/slider';
    import { Label } from '@/components/ui/label';
    import { Button } from '@/components/ui/button';
    import { Instagram } from 'lucide-react';

    const BrandPage = () => {
        const { brandId } = useParams();
        const brand = brands.find(b => b.id === brandId);
        const products = mockProducts.filter(p => p.brand === brandId);

        const allColors = useMemo(() => [...new Set(products.flatMap(p => p.colors))], [products]);
        const allSizes = useMemo(() => [...new Set(products.flatMap(p => p.sizes))], [products]);

        const [priceRange, setPriceRange] = useState([0, 200]);
        const [selectedColors, setSelectedColors] = useState([]);
        const [selectedSizes, setSelectedSizes] = useState([]);
        const [sortOrder, setSortOrder] = useState('default');

        const handleColorChange = (color) => {
            setSelectedColors(prev =>
                prev.includes(color) ? prev.filter(c => c !== color) : [...prev, color]
            );
        };

        const handleSizeChange = (size) => {
            setSelectedSizes(prev =>
                prev.includes(size) ? prev.filter(s => s !== size) : [...prev, size]
            );
        };

        const filteredProducts = useMemo(() => {
            let filtered = products
                .filter(p => p.price >= priceRange[0] && p.price <= priceRange[1])
                .filter(p => selectedColors.length === 0 || p.colors.some(c => selectedColors.includes(c)))
                .filter(p => selectedSizes.length === 0 || p.sizes.some(s => selectedSizes.includes(s)));

            switch (sortOrder) {
                case 'price-asc':
                    filtered.sort((a, b) => a.price - b.price);
                    break;
                case 'price-desc':
                    filtered.sort((a, b) => b.price - a.price);
                    break;
                case 'name-asc':
                    filtered.sort((a, b) => a.name.localeCompare(b.name));
                    break;
                default:
                    break;
            }
            return filtered;
        }, [products, priceRange, selectedColors, selectedSizes, sortOrder]);

        if (!brand) {
            return <div className="text-center py-20">البراند غير موجود.</div>;
        }

        return (
            <>
                <Helmet>
                    <title>{brand.name} - Dream Collection</title>
                    <meta name="description" content={`تصفحي أحدث تشكيلات براند ${brand.name} في Dream Collection.`} />
                </Helmet>
                <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
                    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-center mb-12 border-b pb-8">
                        <img src={brand.logo} alt={`${brand.name} Logo`} className="h-24 mx-auto object-contain mb-4" />
                        <p className="mt-2 text-gray-500">تصفحي أحدث التشكيلات</p>
                        <Button asChild variant="link" className="mt-2 text-pink-600">
                            <a href={brand.instagram} target="_blank" rel="noopener noreferrer">
                                <Instagram className="ml-2 h-4 w-4" />
                                {brand.instagram.replace('https://instagram.com/', '@')}
                            </a>
                        </Button>
                    </motion.div>

                    <div className="flex flex-col md:flex-row gap-8">
                        <aside className="w-full md:w-1/4">
                            <div className="space-y-8 sticky top-24">
                                <div>
                                    <h3 className="font-semibold mb-4">ترتيب حسب</h3>
                                    <select onChange={(e) => setSortOrder(e.target.value)} className="w-full p-2 border rounded-md bg-card">
                                        <option value="default">افتراضي</option>
                                        <option value="price-asc">السعر: من الأقل للأعلى</option>
                                        <option value="price-desc">السعر: من الأعلى للأقل</option>
                                        <option value="name-asc">الاسم</option>
                                    </select>
                                </div>
                                <div>
                                    <Label htmlFor="price-range" className="font-semibold mb-4 block">نطاق السعر</Label>
                                    <Slider
                                        id="price-range"
                                        min={0}
                                        max={200}
                                        step={10}
                                        value={priceRange}
                                        onValueChange={setPriceRange}
                                        className="my-4"
                                    />
                                    <div className="flex justify-between text-sm text-gray-500">
                                        <span>{priceRange[0]} د.أ</span>
                                        <span>{priceRange[1]} د.أ</span>
                                    </div>
                                </div>
                                <div>
                                    <h3 className="font-semibold mb-4">اللون</h3>
                                    <div className="flex flex-wrap gap-2">
                                        {allColors.map(color => (
                                            <button key={color} onClick={() => handleColorChange(color)} className={`px-3 py-1 border rounded-full text-sm ${selectedColors.includes(color) ? 'bg-primary text-white border-primary' : 'bg-card'}`}>
                                                {color}
                                            </button>
                                        ))}
                                    </div>
                                </div>
                                <div>
                                    <h3 className="font-semibold mb-4">المقاس</h3>
                                    <div className="flex flex-wrap gap-2">
                                        {allSizes.map(size => (
                                            <button key={size} onClick={() => handleSizeChange(size)} className={`px-3 py-1 border rounded-full text-sm ${selectedSizes.includes(size) ? 'bg-primary text-white border-primary' : 'bg-card'}`}>
                                                {size}
                                            </button>
                                        ))}
                                    </div>
                                </div>
                            </div>
                        </aside>

                        <main className="w-full md:w-3/4">
                            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
                                {filteredProducts.length > 0 ? (
                                    filteredProducts.map((product, index) => (
                                        <motion.div
                                            key={product.id}
                                            initial={{ opacity: 0, y: 20 }}
                                            animate={{ opacity: 1, y: 0 }}
                                            transition={{ duration: 0.5, delay: index * 0.1 }}
                                        >
                                            <ProductCard product={product} />
                                        </motion.div>
                                    ))
                                ) : (
                                    <p className="col-span-full text-center text-gray-500">لا توجد منتجات تطابق معايير البحث.</p>
                                )}
                            </div>
                        </main>
                    </div>
                </div>
            </>
        );
    };

    export default BrandPage;
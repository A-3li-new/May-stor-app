import React, { Suspense, lazy } from 'react';
    import { Routes, Route, useLocation } from 'react-router-dom';
    import Header from '@/components/layout/Header';
    import Footer from '@/components/layout/Footer';
    import AdminLayout from '@/components/layout/AdminLayout';
    import WhatsappButton from '@/components/shared/WhatsappButton';
    import ProtectedRoute from '@/components/shared/ProtectedRoute';
    import StaffProtection from '@/components/shared/StaffProtection';
    import { NotificationsProvider } from '@/contexts/NotificationContext';

    const HomePage = lazy(() => import('@/pages/HomePage'));
    const BrandPage = lazy(() => import('@/pages/BrandPage'));
    const ProductPage = lazy(() => import('@/pages/ProductPage'));
    const CartPage = lazy(() => import('@/pages/CartPage'));
    const CheckoutPage = lazy(() => import('@/pages/CheckoutPage'));
    const TrackOrderPage = lazy(() => import('@/pages/TrackOrderPage'));
    const OrderSuccessPage = lazy(() => import('@/pages/OrderSuccessPage'));
    const ServicesPage = lazy(() => import('@/pages/ServicesPage'));
    const AboutPage = lazy(() => import('@/pages/AboutPage'));
    const TermsPage = lazy(() => import('@/pages/TermsPage'));
    const AdminLoginPage = lazy(() => import('@/pages/admin/AdminLoginPage'));
    const AdminDashboardPage = lazy(() => import('@/pages/admin/AdminDashboardPage'));
    const AdminProductsPage = lazy(() => import('@/pages/admin/AdminProductsPage'));
    const AdminOrdersPage = lazy(() => import('@/pages/admin/AdminOrdersPage'));
    const AdminStaffPage = lazy(() => import('@/pages/admin/AdminStaffPage'));
    const AdminCouponsPage = lazy(() => import('@/pages/admin/AdminCouponsPage'));
    const AdminSettingsPage = lazy(() => import('@/pages/admin/AdminSettingsPage'));

    function App() {
        const location = useLocation();
        const isAdminRoute = location.pathname.startsWith('/admin');

        return (
            <NotificationsProvider>
                <div className="flex flex-col min-h-screen bg-background text-foreground">
                    {!isAdminRoute && <Header />}
                    <main className="flex-grow">
                        <Suspense fallback={<div className="flex justify-center items-center h-screen">جاري التحميل...</div>}>
                            <Routes>
                                <Route path="/" element={<HomePage />} />
                                <Route path="/brand/:brandId" element={<BrandPage />} />
                                <Route path="/product/:productId" element={<ProductPage />} />
                                <Route path="/cart" element={<CartPage />} />
                                <Route path="/checkout" element={<CheckoutPage />} />
                                <Route path="/track-order" element={<TrackOrderPage />} />
                                <Route path="/order-success/:orderId" element={<OrderSuccessPage />} />
                                <Route path="/services" element={<ServicesPage />} />
                                <Route path="/about" element={<AboutPage />} />
                                <Route path="/terms" element={<TermsPage />} />
                                
                                <Route path="/admin/login" element={<AdminLoginPage />} />
                                
                                <Route path="/admin" element={
                                    <ProtectedRoute>
                                        <AdminLayout>
                                            <AdminDashboardPage />
                                        </AdminLayout>
                                    </ProtectedRoute>
                                } />
                                <Route path="/admin/products" element={
                                    <ProtectedRoute>
                                        <AdminLayout>
                                            <AdminProductsPage />
                                        </AdminLayout>
                                    </ProtectedRoute>
                                } />
                                <Route path="/admin/orders" element={
                                    <ProtectedRoute>
                                        <AdminLayout>
                                            <AdminOrdersPage />
                                        </AdminLayout>
                                    </ProtectedRoute>
                                } />
                                 <Route path="/admin/staff" element={
                                    <ProtectedRoute>
                                        <StaffProtection>
                                            <AdminLayout>
                                                <AdminStaffPage />
                                            </AdminLayout>
                                        </StaffProtection>
                                    </ProtectedRoute>
                                } />
                                 <Route path="/admin/coupons" element={
                                    <ProtectedRoute>
                                        <AdminLayout>
                                            <AdminCouponsPage />
                                        </AdminLayout>
                                    </ProtectedRoute>
                                } />
                                <Route path="/admin/settings" element={
                                    <ProtectedRoute>
                                        <AdminLayout>
                                            <AdminSettingsPage />
                                        </AdminLayout>
                                    </ProtectedRoute>
                                } />
                            </Routes>
                        </Suspense>
                    </main>
                    {!isAdminRoute && <Footer />}
                    <WhatsappButton />
                </div>
            </NotificationsProvider>
        );
    }

    export default App;
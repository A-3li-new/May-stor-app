import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Share2, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useLanguage } from '@/contexts/LanguageContext';
import { useToast } from '@/components/ui/use-toast';

const OrderDialog = ({ isOpen, onClose, onSave, onDelete, order }) => {
  const { t } = useLanguage();
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    customerName: '',
    phone: '',
    address: '',
    model: '',
    size: '',
    color: '',
    price: '',
    notes: '',
    brand: '',
    status: 'pending',
  });

  const brands = [
    { id: 'classic.color.shop', name: t('classicColorShop') },
    { id: 'ghyma68', name: t('ghyma68') },
    { id: 'designerr.mix', name: t('designerrMix') }
  ];

  const statusOptions = [
    { value: 'pending', label: t('pending') },
    { value: 'shipped', label: t('shipped') },
    { value: 'delivered', label: t('delivered') },
    { value: 'returned', label: 'مرتجع' },
    { value: 'cancelled', label: 'ملغي من العميل' },
  ];

  useEffect(() => {
    if (order) {
      setFormData({
        customerName: order.customerName,
        phone: order.phone,
        address: order.address,
        model: order.model || '',
        size: order.size || '',
        color: order.color || '',
        price: order.price ? order.price.toString() : '',
        notes: order.notes || '',
        brand: order.brand,
        status: order.status,
      });
    } else {
      setFormData({
        customerName: '',
        phone: '',
        address: '',
        model: '',
        size: '',
        color: '',
        price: '',
        notes: '',
        brand: '',
        status: 'pending',
      });
    }
  }, [order, isOpen]);

  const handleSubmit = (e) => {
    e.preventDefault();
    onSave(formData);
  };

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleShare = () => {
    toast({
      title: t('featureNotImplemented'),
      description: t('featureNotImplementedDesc'),
      duration: 3000,
    });
  };

  const handleDelete = () => {
    if(order && onDelete) {
        onDelete(order.id);
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50"
            onClick={onClose}
          />
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            className="relative bg-card rounded-xl p-6 w-full max-w-2xl shadow-xl border max-h-[90vh] overflow-y-auto"
          >
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold text-foreground">
                {order ? t('editOrder') : t('addOrder')}
              </h2>
              <div>
                {order && (
                  <Button variant="ghost" size="icon" className="text-destructive" onClick={handleDelete}>
                    <Trash2 className="h-5 w-5" />
                  </Button>
                )}
                <Button variant="ghost" size="icon" onClick={onClose}>
                  <X className="h-5 w-5" />
                </Button>
              </div>
            </div>

            <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Fields */}
              <InputField label={t('customerName')} value={formData.customerName} onChange={(e) => handleChange('customerName', e.target.value)} required />
              <InputField label={t('phone')} value={formData.phone} onChange={(e) => handleChange('phone', e.target.value)} required />
              <InputField label={t('model')} value={formData.model} onChange={(e) => handleChange('model', e.target.value)} />
              <InputField label={t('size')} value={formData.size} onChange={(e) => handleChange('size', e.target.value)} />
              <InputField label={t('color')} value={formData.color} onChange={(e) => handleChange('color', e.target.value)} />
              <InputField label={t('price')} type="number" value={formData.price} onChange={(e) => handleChange('price', e.target.value)} required />
              
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-foreground mb-1">{t('address')}</label>
                <textarea value={formData.address} onChange={(e) => handleChange('address', e.target.value)} className="w-full px-3 py-2 rounded-lg border bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-primary" rows="2" required />
              </div>
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-foreground mb-1">{t('notes')}</label>
                <textarea value={formData.notes} onChange={(e) => handleChange('notes', e.target.value)} className="w-full px-3 py-2 rounded-lg border bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-primary" rows="2" />
              </div>
              
              <SelectField label={t('productBrand')} value={formData.brand} onChange={(e) => handleChange('brand', e.target.value)} options={brands.map(b => ({value: b.id, label: b.name}))} required />
              <SelectField label={t('status')} value={formData.status} onChange={(e) => handleChange('status', e.target.value)} options={statusOptions} required />

              <div className="md:col-span-2 flex gap-3 pt-4">
                <Button type="button" variant="outline" onClick={onClose} className="flex-1">{t('cancel')}</Button>
                <Button type="submit" className="flex-1">{t('save')}</Button>
              </div>
            </form>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

const InputField = ({ label, ...props }) => (
  <div>
    <label className="block text-sm font-medium text-foreground mb-1">{label}</label>
    <input {...props} className="w-full px-3 py-2 rounded-lg border bg-background text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary" />
  </div>
);

const SelectField = ({ label, options, ...props }) => (
  <div>
    <label className="block text-sm font-medium text-foreground mb-1">{label}</label>
    <select {...props} className="w-full px-3 py-2 rounded-lg border bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-primary">
      <option value="">{label}</option>
      {options.map(opt => <option key={opt.value} value={opt.value}>{opt.label}</option>)}
    </select>
  </div>
);

export default OrderDialog;
import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Upload } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useLanguage } from '@/contexts/LanguageContext';

const ProductDialog = ({ isOpen, onClose, onSave, product, brands }) => {
  const { t } = useLanguage();
  const [formData, setFormData] = useState({
    name: '',
    color: '',
    size: '',
    price: '',
    brand: '',
    quantity: '',
    images: [],
  });
  const fileInputRef = useRef(null);

  useEffect(() => {
    if (product) {
      setFormData({
        name: product.name,
        color: product.color || '',
        size: product.size || '',
        price: product.price.toString(),
        brand: product.brand,
        quantity: product.quantity ? product.quantity.toString() : '0',
        images: product.images || (product.image ? [product.image] : []),
      });
    } else {
      setFormData({
        name: '', color: '', size: '', price: '', brand: '', quantity: '0', images: [],
      });
    }
  }, [product, isOpen]);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.name || !formData.price || !formData.brand || !formData.quantity) return;
    onSave({
      ...formData,
      price: parseFloat(formData.price),
      quantity: parseInt(formData.quantity, 10),
      inStock: parseInt(formData.quantity, 10) > 0,
      images: formData.images,
    });
  };

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleImageUpload = (e) => {
    const files = Array.from(e.target.files);
    files.forEach(file => {
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData(prev => ({
          ...prev,
          images: [...prev.images, reader.result]
        }));
      };
      reader.readAsDataURL(file);
    });
  };

  const handleRemoveImage = (idx) => {
    setFormData(prev => ({
      ...prev,
      images: prev.images.filter((_, i) => i !== idx)
    }));
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 bg-black/50" onClick={onClose} />
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            className="relative bg-card rounded-xl p-6 w-full max-w-lg shadow-xl border max-h-[90vh] overflow-y-auto"
          >
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold text-foreground">{product ? t('editProduct') : t('addProduct')}</h2>
              <Button variant="ghost" size="icon" onClick={onClose}><X className="h-5 w-5" /></Button>
            </div>
            <form onSubmit={handleSubmit} className="space-y-4">
              <input type="file" ref={fileInputRef} onChange={handleImageUpload} className="hidden" accept="image/*" multiple />
              <div className="w-full min-h-24 bg-muted/50 rounded-lg flex flex-wrap gap-2 items-center justify-center border-2 border-dashed cursor-pointer p-2" onClick={() => fileInputRef.current.click()}>
                {formData.images.length > 0 ? (
                  formData.images.map((img, idx) => (
                    <div key={idx} className="relative w-20 h-20">
                      <img src={img} alt={`Preview ${idx}`} className="w-full h-full object-cover rounded-lg border" />
                      <button type="button" className="absolute top-0 right-0 bg-red-500 text-white rounded-full p-1" onClick={e => {e.stopPropagation(); handleRemoveImage(idx);}}><X className="h-4 w-4" /></button>
                    </div>
                  ))
                ) : (
                  <div className="text-center text-muted-foreground">
                    <Upload className="h-10 w-10 mx-auto mb-2" />
                    <p>{t('uploadImages') || 'رفع صور المنتج'}</p>
                  </div>
                )}
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <InputField label={t('productName')} value={formData.name} onChange={(e) => handleChange('name', e.target.value)} required />
                <InputField label={t('price')} type="number" value={formData.price} onChange={(e) => handleChange('price', e.target.value)} required />
                <InputField label={t('color')} value={formData.color} onChange={(e) => handleChange('color', e.target.value)} />
                <InputField label={t('size')} value={formData.size} onChange={(e) => handleChange('size', e.target.value)} />
                <InputField label={t('quantity')} type="number" value={formData.quantity} onChange={(e) => handleChange('quantity', e.target.value)} required />
                <SelectField label={t('productBrand')} value={formData.brand} onChange={(e) => handleChange('brand', e.target.value)} options={brands.map(b => ({value: b.id, label: b.name}))} required />
              </div>
              <div className="flex gap-3 pt-4">
                <Button type="button" variant="outline" onClick={onClose} className="flex-1">{t('cancel')}</Button>
                <Button type="submit" className="flex-1">{t('save')}</Button>
              </div>
            </form>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

const InputField = ({ label, ...props }) => (
  <div>
    <label className="block text-sm font-medium text-foreground mb-1">{label}</label>
    <input {...props} className="w-full px-3 py-2 rounded-lg border bg-background text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary" />
  </div>
);

const SelectField = ({ label, options, ...props }) => (
  <div>
    <label className="block text-sm font-medium text-foreground mb-1">{label}</label>
    <select {...props} className="w-full px-3 py-2 rounded-lg border bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-primary">
      <option value="">{label}</option>
      {options.map(opt => <option key={opt.value} value={opt.value}>{opt.label}</option>)}
    </select>
  </div>
);

export default ProductDialog;